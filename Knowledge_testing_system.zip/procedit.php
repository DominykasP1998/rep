<?php
session_start();

include("include/nustatymai.php");
include("include/functions.php");

// cia sesijos kontrole
if (!isset($_SESSION['prev']) || ($_SESSION['ulevel'] != $user_roles[TEACHER_LEVEL]) || (($_SESSION['prev'] != "modifikuoti") && ($_SESSION['prev'] != "editname") && ($_SESSION['prev'] != "procedit")))
{ header("Location: logout.php");exit;}

$_SESSION['messageedit']="";

$_SESSION['title_error']="";

//$_SESSION['question']=$question;
//$_SESSION['answer']=$answer;
//$_SESSION['worth']=$worth;

$title=strtolower($_POST['pavadinimas']);


$_SESSION['prev']="procedit";

$username = $_SESSION['user'];
$name = $_SESSION['namedit'];

        if (checktesttitle($title))
		{ 
     
		 list($dbtitle)=checkdbtitle($title, $username);  //patikrinam DB       
         if ($dbtitle)  {  // jau yra toks vartotojas DB
		     $_SESSION['title_error']= 
				 "<font size=\"2\" color=\"#ff0000\">* Testą tokiu pavadinimu jau esate sukūręs</font>";
				 }
         else {
			   $_SESSION['title_error']= "";

		 $db=mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);
		$reqname = "SELECT testo_sudarytojas FROM " . TBL_TESTAI ." WHERE pavadinimas = '$name'";
	    $rez = mysqli_query($db, $reqname);
	    $roww = mysqli_fetch_assoc($rez);
	    $namee = $roww['testo_sudarytojas'];
	if ($username != $namee) {header("Location: logout.php");exit; }		   
		 $updatekl = "UPDATE " . TBL_TESTAI. " SET pavadinimas = '$title' WHERE pavadinimas = '$name'";

				   
		 if (mysqli_query($db, $updatekl)) 
		      {$_SESSION['messageedit']="Testo '$name' pavadinimas sėkmingai pakeistas į '$title'";}
         else {$_SESSION['messageedit']="Testo pavadinimo pakeisti nepavyko:" . $updatekl . "<br>" . mysqli_error($db);}
         
             header("Location:modifikuoti.php"); exit;
				    
		}
		}
        // griztam taisyti
         // session_regenerate_id(true);
          header("Location:editname.php?name=$name");exit;
?>