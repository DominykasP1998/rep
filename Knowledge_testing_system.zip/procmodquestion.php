<?php
session_start();
// cia sesijos kontrole
if (!isset($_SESSION['prev']) || (($_SESSION['prev'] != "editquestion") && ($_SESSION['prev'] != "modquestion")))
{ header("Location: logout.php");exit;}

include("include/nustatymai.php");
include("include/functions.php");

$_SESSION['messageedit']="";

$_SESSION['question_error'] = "";
$_SESSION['answer_error'] = "";
$_SESSION['worth_error'] = "";


$klausimas=strtolower($_POST['klausimas']);
$atsakymas=strtolower($_POST['atsakymas']);
$verte=strtolower($_POST['verte']);

$_SESSION['prev']="procmodquestion";
$username = $_SESSION['user'];

$name = $_SESSION['namedit'];
$question = $_SESSION['quesedit'];
$answer = $_SESSION['ansedit'];
$worth = $_SESSION['woredit'];

        if (checktestquestion($klausimas))
		{ 
     
			 
			   $_SESSION['question_error']= "";
            if (checktestanswer($atsakymas) && checktestworth($verte))
			{
		 $db=mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);
				   
		 $updatekl = "UPDATE " . TBL_KLAUSIMAI. " SET klausimas = '$klausimas', atsakymas = '$atsakymas', verte_balais = '$verte' WHERE klausimas = '$question'";

		$reqname = "SELECT testo_sudarytojas FROM " . TBL_TESTAI ." WHERE pavadinimas = '$name'";
	    $rez = mysqli_query($db, $reqname);
	    $roww = mysqli_fetch_assoc($rez);
	    $namee = $roww['testo_sudarytojas'];
	if ($username != $namee) {header("Location: logout.php");exit; }
				   
		 if (mysqli_query($db, $updatekl)) 
		      {$_SESSION['messageedit']="Klausimas redaguotas sėkmingai";}
         else {$_SESSION['messageedit']="Klausimo redaguoti nepavyko:" . $updatekl . "<br>" . mysqli_error($db);}
         
             header("Location:editquestion.php?name=$name"); exit;
				    
		}
		 }
		
        // griztam taisyti
         // session_regenerate_id(true);
          header("Location:modquestion.php?name=$name&question=$question&answer=$answer&worth=$worth");exit;
?>