<?php
session_start();

include("include/nustatymai.php");
include("include/functions.php");
// cia sesijos kontrole
if (!isset($_SESSION['prev']) || ($_SESSION['ulevel'] != $user_roles[TEACHER_LEVEL]) || (($_SESSION['prev'] != "modifikuoti") && ($_SESSION['prev'] != "editname") && ($_SESSION['prev'] != "procedit")))
{ header("Location: logout.php");exit;}


$_SESSION['messageedit'] = "";

$_SESSION['namedit'] = $_GET['name'];
$name = $_SESSION['namedit'];

$_SESSION['prev'] = "editname";
?>

<html>
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=9; text/html; charset=utf-8">
        <title>Pavadinimo keitimas</title>
        <link href="include/styles.css" rel="stylesheet" type="text/css" >
    </head>
    <body>
        <table class="center" ><tr><td>
			<center><h1>Žinių testavimo sistema</h1></center>
			<center>Dominykas Pašukys IFB7</center><br/>
        </td></tr><tr><td>

			<?php
			
			  echo "<div align=\"center\">";echo "<font size=\"4\" color=\"#ff0000\">".$_SESSION['messageedit'] . "<br></font>";   
			  $_SESSION['messageedit'] = "";
			?>
			 <?php echo "<table class=\"center\"><tr><td>"; ?> 
          <form action="procedit.php?name=$name" method="POST" class="login">             
        <center style="font-size:18pt;"><b>Testo pavadinimo keitimas</b></center>
        <p style="text-align:left;">Pavadinimas:<br>
            <input class ="s1" name="pavadinimas" type="text" value="<?php echo $name;  ?>"/><br>
			<?php echo $_SESSION['title_error']; 
			?>
        </p>
        <p style="text-align:left;">
            <input type="submit" name="update" value="Atnaujinti"/>     
        </p>
    </form>
			<?php echo "</td></tr></table></div><br>"; ?>
			<?php echo "<p align=\"center\">[<a class=\"link\" href=\"modifikuoti.php\">Atgal</a>]</p>"; ?>

			
	</body>
</html>