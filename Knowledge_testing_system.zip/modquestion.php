<?php
session_start();
include("include/nustatymai.php");
include("include/functions.php");
// cia sesijos kontrole
if (!isset($_SESSION['prev']) || ($_SESSION['ulevel'] != $user_roles[TEACHER_LEVEL]) || (($_SESSION['prev'] != "editquestion") && ($_SESSION['prev'] != "modquestion") && ($_SESSION['prev'] != "procmodquestion")))
{ header("Location: logout.php");exit;}


$_SESSION['messageedit'] = "";

$_SESSION['namedit'] = $_GET['name'];
$name = $_SESSION['namedit'];

$_SESSION['quesedit'] = $_GET['question'];
$question = $_SESSION['quesedit'];

$_SESSION['ansedit'] = $_GET['answer'];
$answer = $_SESSION['ansedit'];

$_SESSION['woredit'] = $_GET['worth'];
$worth = $_SESSION['woredit'];

$_SESSION['prev'] = "modquestion";
?>

<html>
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=9; text/html; charset=utf-8">
        <title>Klausimo redagavimas</title>
        <link href="include/styles.css" rel="stylesheet" type="text/css" >
    </head>
    <body>
        <table class="center" ><tr><td>
			<center><h1>Žinių testavimo sistema</h1></center>
			<center>Dominykas Pašukys IFB7</center><br/>
        </td></tr><tr><td>

			<?php
			
			  echo "<div align=\"center\">";echo "<font size=\"4\" color=\"#ff0000\">".$_SESSION['messageedit'] . "<br></font>";   
			?>
			 <?php echo "<table class=\"center\"><tr><td>"; ?> 
          <form action="procmodquestion.php?name=$name&question=$question&answer=$answer&worth=$worth" method="POST" class="login">             
        <center style="font-size:18pt;"><b>Klausimo redagavimas</b></center>
        <p style="text-align:left;">Klausimas:<br>
            <input class ="s1" name="klausimas" type="text" value="<?php echo $question;  ?>"/><br>
			<?php echo $_SESSION['question_error']; 
			?>
        </p>
		<p style="text-align:left;">Atsakymas:<br>
            <input class ="s1" name="atsakymas" type="text" value="<?php echo $answer;  ?>"/><br>
			<?php echo $_SESSION['answer_error']; 
			?>
        </p>
		<p style="text-align:left;">Vertė balais:<br>
            <input class ="s1" name="verte" type="number" value="<?php echo $worth;  ?>"/><br>
			<?php echo $_SESSION['worth_error']; 
			?>
        </p>
        <p style="text-align:left;">
            <input type="submit" name="update" value="Atnaujinti"/>     
        </p>
    </form>
			<?php echo "</td></tr></table></div><br>"; ?>
			<?php echo "<p align=\"center\">[<a class=\"link\" href=\"editquestion.php?name=$name\">Atgal</a>]</p>"; ?>

			
	</body>
</html>