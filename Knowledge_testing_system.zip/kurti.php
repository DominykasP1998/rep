<?php

session_start();

include("include/functions.php");
include("include/nustatymai.php");

if (!isset($_SESSION['prev']) || ($_SESSION['ulevel'] != $user_roles[TEACHER_LEVEL]) || (($_SESSION['prev'] != "index") && ($_SESSION['prev'] != "kurti") && ($_SESSION['prev'] != "proccreate")))
{ header("Location: logout.php");exit;}

$_SESSION['prev'] = "kurti";

?>

<html>
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=9; text/html; charset=utf-8">
        <title>Žinių testavimo sistema</title>
        <link href="include/styles.css" rel="stylesheet" type="text/css" >
    </head>
    <body>
        <table class="center" ><tr><td>
			<center><h1>Žinių testavimo sistema</h1></center>
			<center>Dominykas Pašukys IFB7</center><br/>
        </td></tr><tr><td>

			<?php
			
			  echo "<div align=\"center\">";echo "<font size=\"4\" color=\"#ff0000\">".$_SESSION['message'] . "<br></font>";   
			
			  echo "<table class=\"center\"><tr><td>";
              include("include/create.php");  
              echo "</td></tr></table></div><br>";
			  echo "<p align=\"center\">[<a class=\"link\" href=\"index.php\">Atgal į pradžią</a>]</p>";

			?>
	</body>
</html>