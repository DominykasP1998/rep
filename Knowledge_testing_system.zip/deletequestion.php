<?php
session_start();

include("include/nustatymai.php");
include("include/functions.php");

// cia sesijos kontrole
if (!isset($_SESSION['prev']) || ($_SESSION['ulevel'] != $user_roles[TEACHER_LEVEL]) || (($_SESSION['prev'] != "editquestion") && ($_SESSION['prev'] != "deletequestion")))
{ header("Location: logout.php");exit;}

$_SESSION['prev'] = "deletequestion";
//$_SESSION['messageedit']="";

$name = $_GET['name'];
$question = $_GET['question'];

         $db=mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);
		
        $reqname = "SELECT testo_sudarytojas FROM " . TBL_TESTAI ." WHERE pavadinimas = '$name'";
	    $rez = mysqli_query($db, $reqname);
	    $roww = mysqli_fetch_assoc($rez);
	    $namee = $roww['testo_sudarytojas'];
	if ($username != $namee) {header("Location: logout.php");exit; }
		 $delete = "DELETE FROM " . TBL_KLAUSIMAI. " WHERE testo_pavadinimas = '$name' AND klausimas = '$question'";		 				   
		 
				   
		 if (mysqli_query($db, $delete)) 
		      {$_SESSION['messageedit']="Klausimas '$question' pašalintas iš testo";}
         else {$_SESSION['messageedit']="Klaida šalinant klausimą:" . $delete . "<br>" . mysqli_error($db);}
         
             header("Location:editquestion.php?name=$name"); exit;
?>