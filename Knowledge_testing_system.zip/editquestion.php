<?php
// admin.php
// vartotojų įgaliojimų keitimas ir naujo vartotojo registracija, jei leidžia nustatymai
// galima keisti vartotojų roles, tame tarpe uzblokuoti ir/arba juos pašalinti
// sužymėjus pakeitimus į procadmin.php, bus dar perklausta

session_start();
include("include/nustatymai.php");
include("include/functions.php");
// cia sesijos kontrole
if (!isset($_SESSION['prev']) || ($_SESSION['ulevel'] != $user_roles[TEACHER_LEVEL]) || (($_SESSION['prev'] != "modifikuoti") && ($_SESSION['prev'] != "editquestion") && ($_SESSION['prev'] != "addquestion") && ($_SESSION['prev'] != "procaddquestion") && ($_SESSION['prev'] != "deletequestion") && ($_SESSION['prev'] != "modquestion") && ($_SESSION['prev'] != "procmodquestion")))  
{ header("Location: logout.php");exit;}

$_SESSION['prev']="editquestion";
$_SESSION['namedit']=$_GET['name'];
$name = $_SESSION['namedit'];
$username = $_SESSION['user'];
?>
<html>
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=9; text/html; charset=utf-8">
        <title>Klausimų modifikavimas</title>
        <link href="include/styles.css" rel="stylesheet" type="text/css" >
    </head>
    <body>
        <table class="center" ><tr><td>
			<center><h1>Žinių testavimo sistema</h1></center>
            </td></tr><tr><td>
		<center><font size="5">Klausimų šalinimas, redagavimas, naujo pridėjimas</font></center></td></tr></table> <br>
		<center><b><?php echo $_SESSION['messageedit']; $_SESSION['messageedit'] = "";?></b></center>
	
	    <table class="center" style=" width:75%; border-width: 3px; border-style: dashed; border-color: black;">
			<tr><td width=50%><center><a class="link" href="modifikuoti.php">[Atgal]</a></center></td><td width=50%><center><a class="link" href="addquestion.php">[Pridėti klausimą]</a></center></td></tr></table> <br> 
		    
<?php
	$db=mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);
		 
	$sql = "SELECT * "
            . "FROM " . TBL_KLAUSIMAI . " WHERE testo_pavadinimas = '$name' ORDER BY testo_pavadinimas DESC";
	$result = mysqli_query($db, $sql);
		
	$reqname = "SELECT testo_sudarytojas FROM " . TBL_TESTAI ." WHERE pavadinimas = '$name'";
	$rez = mysqli_query($db, $reqname);
	$roww = mysqli_fetch_assoc($rez);
	$namee = $roww['testo_sudarytojas'];
	if ($username != $namee) {header("Location: logout.php");exit; }
	if (!$result || (mysqli_num_rows($result) < 1))  
			{echo "Šis testas klausimų kolkas neturi."; exit;}
?>
    <table class="center"  border="1" cellspacing="0" cellpadding="3">
    <tr><td><center><b>Priklauso testui?</b></center></td><td><center><b>Klausimas</b></center></td><td><center><b>Atsakymas</b></center></td><td><center><b>Vertė balais</b></center></td><td><center><b>Redaguoti klausimą?</b></center></td><td><center><b>Trinti klausimą?</b></center></td></tr>
<?php
        while($row = mysqli_fetch_assoc($result)) 
	{	 
	    $pav=$row['testo_pavadinimas'];
	  	$question=$row['klausimas'];
		$answer=$row['atsakymas'];
		$worth=$row['verte_balais'];
      	echo "<tr><td><center>".$pav. "</center></td>";
    	echo "<td><center>".$question. "</center></td>";
		echo "<td><center>".$answer. "</center></td>";
		echo "<td><center>".$worth. "</center></td>";
        echo "<td><center><a class=\"link\" href=\"modquestion.php?name=$pav&question=$question&answer=$answer&worth=$worth\">Redaguoti</a></center></td>";  
        echo "<td><center><a class=\"link\" href=\"deletequestion.php?name=$pav&question=$question\">Trinti</a></center></td></tr>";
   }
?>
        </table>
		
    </body></html>
