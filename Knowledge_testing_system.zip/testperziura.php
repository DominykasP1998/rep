<?php

session_start();
include("include/nustatymai.php");
include("include/functions.php");
// cia sesijos kontrole
if (!isset($_SESSION['prev']) || ($_SESSION['ulevel'] != $user_roles[TEACHER_LEVEL]) || (($_SESSION['prev'] != "index") && ($_SESSION['prev'] != "testperziura")))
{ header("Location: logout.php");exit;}

$_SESSION['prev']="testperziura";

?>

<html>
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=9; text/html; charset=utf-8">
        <title>Spręstų testų peržiūra</title>
        <link href="include/styles.css" rel="stylesheet" type="text/css" >
    </head>
    <body>
        <table class="center" ><tr><td>
			<center><h1>Žinių testavimo sistema</h1></center>
            </td></tr><tr><td>
		<center><font size="5">Studentų spręstų testų gautų įvertinimų peržiūra</font></center></td></tr></table> <br>
	
	    <table class="center" style=" width:75%; border-width: 3px; border-style: dashed; border-color: black;">
			<tr><td width=100%><center><a class="link" href="index.php">[Atgal į pradžią]</a></center></td><td width=100%></tr></table> <br> 
		    
<?php
		
    $sudare = $_SESSION['user'];
		
	$db=mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);
		
	$reqname = "SELECT slapyvardis FROM " . TBL_USERS. " WHERE slapyvardis = '$sudare'";
		 
	$resultas = mysqli_query($db, $reqname);
		 
    $roww = mysqli_fetch_assoc($resultas);
		 
	$useris = $roww['slapyvardis'];
		
	$sql = "SELECT * "
            . "FROM " . TBL_SPR . " WHERE testo_kurejas = '$useris'";
		
	$result = mysqli_query($db, $sql);
		
	if (!$result || (mysqli_num_rows($result) < 1))  
			{echo "Kolkas nei vienas studentas nesprendė Jūsų testo(-ų)."; exit;}
?>
    <table class="center"  border="1" cellspacing="0" cellpadding="3">
    <tr><td><center><b>Studentas</b></center></td><td><center><b>Testo pavadinimas</b></center></td><td><center><b>Testo autorius</b></center></td><td><center><b>Kada baigė spręsti</b></center></td><td><center><b>Gautas įvertinimas</b></center></td></tr>
<?php
        while($row = mysqli_fetch_assoc($result)) 
	{	 
	    $pav = $row['testo_pavadinimas'];
	  	$creator = $row['testo_kurejas'];
		$stud = $row['autorius'];
		$time = $row['laikas'];
		$ivertis = $row['gautas_ivertis'];
			
      	echo "<tr><td><center>".$stud. "</center></td>";
    	echo "<td><center>".$pav. "</center></td>";
		echo "<td><center>".$creator. "</center></td>";	
		echo "<td><center>".$time. "</center></td>";
		echo "<td><center>".$ivertis. "</center></td></tr>";
   }
?>
        </table>
    </body></html>
