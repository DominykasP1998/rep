-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 07, 2019 at 01:13 AM
-- Server version: 5.7.24-0ubuntu0.16.04.1
-- PHP Version: 7.2.12-1+ubuntu16.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vartvald`
--

-- --------------------------------------------------------

--
-- Table structure for table `Klausimai`
--

CREATE TABLE `Klausimai` (
  `klausimo_nr` int(11) NOT NULL,
  `klausimas` varchar(100) CHARACTER SET utf8 COLLATE utf8_lithuanian_ci NOT NULL,
  `atsakymas` varchar(100) CHARACTER SET utf8 COLLATE utf8_lithuanian_ci NOT NULL,
  `verte_balais` int(2) NOT NULL,
  `testo_pavadinimas` varchar(30) CHARACTER SET utf8 COLLATE utf8_lithuanian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Klausimai`
--

INSERT INTO `Klausimai` (`klausimo_nr`, `klausimas`, `atsakymas`, `verte_balais`, `testo_pavadinimas`) VALUES
(49, 'ka reiskia good morning?', 'labas rytas', 1, 'anglu testas'),
(50, 'ka reiskia good evening?', 'labas vakaras', 1, 'anglu testas'),
(51, 'isverskite sakini - i bought a new guitar. (atsakyme lietuvisku raidziu nenaudoti)', 'as nusipirkau nauja gitara', 3, 'anglu testas'),
(52, 'apskaiciuokite 8(10-5)', '40', 2, 'matematikos kontrolinis'),
(53, 'isspreskite lygti 20x = 100', '5', 2, 'matematikos kontrolinis'),
(54, 'kas pirmiau atliekama - sudetis ar daugyba?', 'daugyba', 1, 'matematikos kontrolinis'),
(56, 'suraskite y 5y - 20 = 20 ', '8', 3, 'matematikos kontrolinis'),
(58, 'apskaiciuokite -200-100*2-(-18)', '-382', 2, 'matematikos kontrolinis'),
(59, 'koks zemynas pats didziausias?', 'azija', 5, 'geografija'),
(60, 'kuriame zemyne gyvena maziausiai gyventoju?', 'antarktidoje', 5, 'geografija'),
(65, 'a', 'b', 1, 'geografija');

-- --------------------------------------------------------

--
-- Table structure for table `Registruoti_vartotojai`
--

CREATE TABLE `Registruoti_vartotojai` (
  `slapyvardis` varchar(20) NOT NULL,
  `slaptazodis` varchar(32) NOT NULL,
  `vartotojo_lygis` int(1) NOT NULL,
  `laiko_zyme` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Registruoti_vartotojai`
--

INSERT INTO `Registruoti_vartotojai` (`slapyvardis`, `slaptazodis`, `vartotojo_lygis`, `laiko_zyme`) VALUES
('dest', 'a1edddf2cb59b7bbc0218e03c305de6c', 5, '2019-12-06 23:10:40'),
('dest2', '69327ecb75da1ddd45cd412b49c74368', 5, '2019-12-06 22:58:13'),
('stud', 'c2acd92812ef99acd3dcdbb746b9a434', 4, '2019-12-06 23:09:36'),
('stud2', 'f31a7bd22079a4078616be52012aa5c5', 4, '2019-12-06 16:07:28'),
('test', '081884c7d659a2feaa0c55ad015a3bf4', 9, '2019-12-06 21:44:44');

-- --------------------------------------------------------

--
-- Table structure for table `Spresti_testai`
--

CREATE TABLE `Spresti_testai` (
  `gautas_ivertis` int(2) NOT NULL,
  `id` int(11) NOT NULL,
  `autorius` varchar(20) NOT NULL,
  `testo_pavadinimas` varchar(30) CHARACTER SET utf8 COLLATE utf8_lithuanian_ci NOT NULL,
  `laikas` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `testo_kurejas` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Spresti_testai`
--

INSERT INTO `Spresti_testai` (`gautas_ivertis`, `id`, `autorius`, `testo_pavadinimas`, `laikas`, `testo_kurejas`) VALUES
(3, 32, 'stud', 'anglu testas', '2019-12-06 15:44:46', 'dest'),
(5, 33, 'stud', 'anglu testas', '2019-12-06 15:45:28', 'dest'),
(6, 34, 'stud', 'matematikos kontrolinis', '2019-12-06 15:52:49', 'dest'),
(2, 36, 'stud2', 'anglu testas', '2019-12-06 16:07:45', 'dest'),
(10, 37, 'stud2', 'matematikos kontrolinis', '2019-12-06 16:09:34', 'dest'),
(0, 39, 'stud', 'anglu testas', '2019-12-06 23:09:45', 'dest');

-- --------------------------------------------------------

--
-- Table structure for table `Testai`
--

CREATE TABLE `Testai` (
  `pavadinimas` varchar(30) CHARACTER SET utf8 COLLATE utf8_lithuanian_ci NOT NULL,
  `testo_sudarytojas` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Testai`
--

INSERT INTO `Testai` (`pavadinimas`, `testo_sudarytojas`) VALUES
('anglu testas', 'dest'),
('matematikos kontrolinis', 'dest'),
('geografija', 'dest2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Klausimai`
--
ALTER TABLE `Klausimai`
  ADD PRIMARY KEY (`klausimo_nr`),
  ADD KEY `IEINA` (`testo_pavadinimas`);

--
-- Indexes for table `Registruoti_vartotojai`
--
ALTER TABLE `Registruoti_vartotojai`
  ADD PRIMARY KEY (`slapyvardis`);

--
-- Indexes for table `Spresti_testai`
--
ALTER TABLE `Spresti_testai`
  ADD PRIMARY KEY (`id`),
  ADD KEY `SPRENDZIA` (`autorius`),
  ADD KEY `SUKURIA3` (`testo_kurejas`),
  ADD KEY `ISSPRENDZIAMAS` (`testo_pavadinimas`);

--
-- Indexes for table `Testai`
--
ALTER TABLE `Testai`
  ADD PRIMARY KEY (`pavadinimas`),
  ADD KEY `SUKURIA` (`testo_sudarytojas`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Klausimai`
--
ALTER TABLE `Klausimai`
  MODIFY `klausimo_nr` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;
--
-- AUTO_INCREMENT for table `Spresti_testai`
--
ALTER TABLE `Spresti_testai`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `Klausimai`
--
ALTER TABLE `Klausimai`
  ADD CONSTRAINT `IEINA` FOREIGN KEY (`testo_pavadinimas`) REFERENCES `Testai` (`pavadinimas`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `Spresti_testai`
--
ALTER TABLE `Spresti_testai`
  ADD CONSTRAINT `ISSPRENDZIAMAS` FOREIGN KEY (`testo_pavadinimas`) REFERENCES `Testai` (`pavadinimas`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `SPRENDZIA` FOREIGN KEY (`autorius`) REFERENCES `Registruoti_vartotojai` (`slapyvardis`),
  ADD CONSTRAINT `SUKURIA3` FOREIGN KEY (`testo_kurejas`) REFERENCES `Testai` (`testo_sudarytojas`) ON DELETE CASCADE;

--
-- Constraints for table `Testai`
--
ALTER TABLE `Testai`
  ADD CONSTRAINT `SUKURIA` FOREIGN KEY (`testo_sudarytojas`) REFERENCES `Registruoti_vartotojai` (`slapyvardis`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
