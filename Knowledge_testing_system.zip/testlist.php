<?php

session_start();
include("include/nustatymai.php");
include("include/functions.php");
// cia sesijos kontrole
if (!isset($_SESSION['prev']) || ($_SESSION['ulevel'] != $user_roles[STUDENT_LEVEL]) || (($_SESSION['prev'] != "index") && ($_SESSION['prev'] != "testlist") && ($_SESSION['prev'] != "spresti") && ($_SESSION['prev'] != "procspresti")))  
{ header("Location: logout.php");exit;}

$_SESSION['prev']="testlist";

?>
<html>
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=9; text/html; charset=utf-8">
        <title>Tavo testai</title>
        <link href="include/styles.css" rel="stylesheet" type="text/css" >
    </head>
    <body>
        <table class="center" ><tr><td>
			<center><h1>Žinių testavimo sistema</h1></center>
            </td></tr><tr><td>
		<center><font size="5">Galimų spręsti testų sąrašas</font></center></td></tr></table> <br>
		<center><b><?php echo $_SESSION['testnews']; $_SESSION['testnews'] = ""; ?></b></center>
	
	    <table class="center" style=" width:75%; border-width: 3px; border-style: dashed; border-color: black;">
			<tr><td width=50%><center><a class="link" href="index.php">[Atgal į pradžią]</a></center></td></tr></table> <br> 
		    
<?php
	$db=mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);
		 
	$sql = "SELECT * "
            . "FROM " . TBL_TESTAI;
	$result = mysqli_query($db, $sql);
	if (!$result || (mysqli_num_rows($result) < 1))  
			{echo "Galimų spręsti testų kolkas nėra"; exit;}
?>
    <table class="center"  border="1" cellspacing="0" cellpadding="3">
    <tr><td><center><b>Pavadinimas</b></center></td><td><center><b>Autorius</b></center></td><td><center><b>Spręsti?</b></center></td></tr>
<?php
        while($row = mysqli_fetch_assoc($result)) 
	{	 
	    $pav=$row['pavadinimas'];
	  	$sudar=$row['testo_sudarytojas'];
      	echo "<tr><td><center>".$pav. "</center></td>";
    	echo "<td><center>".$sudar. "</center></td>";
        echo "<td><center><a class=\"link\" href=\"spresti.php?name=$pav&author=$sudar\">Spręsti</a></center></td></tr>";  
   }
?>
        </table>
		
    </body>
</html>
