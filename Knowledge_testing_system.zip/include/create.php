<?php
if (!isset($_SESSION)) { header("Location: logout.php");exit;}
?>
<form action="proccreate.php" method="POST" class="login">             
        <center style="font-size:18pt;"><b>Naujo testo kūrimas</b></center>
        <p style="text-align:left;">Pavadinimas:<br>
            <input class ="s1" name="pavadinimas" type="text" value="<?php echo $_SESSION['title'];  ?>"/><br>
			<?php echo $_SESSION['title_error']; 
			?>
        </p>
        <p style="text-align:left;">Klausimas:<br>
            <input class ="s1" name="klausimas" type="text" value="<?php echo $_SESSION['question'];  ?>"/><br>
          <?php echo $_SESSION['question_error']; 
			?>
        </p> 
	    <p style="text-align:left;">Atsakymas:<br>
            <input class ="s1" name="atsakymas" type="text" value="<?php echo $_SESSION['answer'];  ?>"/><br>
          <?php echo $_SESSION['answer_error']; 
			?>
        </p>
	    <p style="text-align:left;">Vertė balais:<br>
            <input class ="s1" name="verte" type="number" value="1" value="<?php echo $_SESSION['worth'];  ?>"/><br>
			<?php echo $_SESSION['worth_error']; 
			?>
        </p>  
        <p style="text-align:left;">
            <input type="submit" name="create" value="Sukurti"/>     
        </p>
    </form>