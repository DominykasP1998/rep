<?php
if (!isset($_SESSION)) { header("Location: logout.php");exit;}
?>
<form action="procedit.php" method="POST" class="login">             
        <center style="font-size:18pt;"><b>Testo pavadinimo keitimas</b></center>
        <p style="text-align:left;">Pavadinimas:<br>
            <input class ="s1" name="pavadinimas" type="text" value="<?php echo $_SESSION['title'];  ?>"/><br>
			<?php echo $_SESSION['title_error']; 
			?>
        </p>
        <p style="text-align:left;">
            <input type="submit" name="update" value="Atnaujinti"/>     
        </p>
    </form>