<?php
// funkcijos  include/functions.php

function inisession($arg) {   //valom sesijos kintamuosius
            if($arg =="full"){
                $_SESSION['message']="";
                $_SESSION['user']="";
	       		$_SESSION['ulevel']=0;
				$_SESSION['userid']=0;
				//$_SESSION['umail']=0;
            }			    	 
		$_SESSION['name_login']="";
		$_SESSION['pass_login']="";
		$_SESSION['name_error']="";
      	$_SESSION['pass_error']="";
	    $_SESSION['title']="";
	    $_SESSION['title_error']="";
	    $_SESSION['question']="";
		$_SESSION['question_error']="";
	    $_SESSION['answer']="";
		$_SESSION['answer_error']="";
	    $_SESSION['worth']="";
		$_SESSION['worth_error']="";
        }

function checktesttitle($title) {
	if (!$title || strlen($title = trim($title)) == 0)
		{
		$_SESSION['title_error']=
				 "<font size=\"2\" color=\"#ff0000\">* Neįvestas testo pavadinimas</font>";
			 "";
			 return false;
		}
	elseif (!preg_match("/^([ 0-9a-zA-Zą-žĄ-Ž ])*$/", $title))
			{
		$_SESSION['title_error']=
				"<font size=\"2\" color=\"#ff0000\">* Testo pavadinimas gali būti sudarytas<br>
				&nbsp;&nbsp;tik iš raidžių ir skaičių</font>";
		     return false;
			}
	else {
		return true;
	}
}
function checktestquestion($question) {
	if (!$question || strlen($question = trim($question)) == 0)
		{
		$_SESSION['question_error']=
				 "<font size=\"2\" color=\"#ff0000\">* Neįvestas klausimas</font>";
			 "";
			 return false;
		}
	else {
		return true;
	}
}
function checktestanswer($answer) {
	if (!$answer || strlen($answer = trim($answer)) == 0)
		{
		$_SESSION['answer_error']=
				 "<font size=\"2\" color=\"#ff0000\">* Neįvestas atsakymas</font>";
			 "";
			 return false;
	}
	else {
		return true;
	}
}

function checktestworth($worth) {
	if (!$worth)
		{
		$_SESSION['worth_error']=
				 "<font size=\"2\" color=\"#ff0000\">* Neįvesta atsakymo vertė balais</font>";
			 "";
			 return false;
		}
	   elseif (!preg_match("/^([1-9])*$/", $worth))
			{
		$_SESSION['worth_error']=
				"<font size=\"2\" color=\"#ff0000\">* Vertė turi būti įvesta<br>
				&nbsp;&nbsp;tik skaičiu pradedant nuo vieno</font>";
		     return false;
			}
	elseif (strlen($worth = trim($worth)) > 2)
			{
		$_SESSION['worth_error']=
				"<font size=\"2\" color=\"#ff0000\">* Įvertinimas negali būti didesnis nei du skaitmenys</font>";
		     return false;
			}
	else {
		return true;
	}
}

function checkname ($username){   // Vartotojo vardo sintakse
	   if (!$username || strlen($username = trim($username)) == 0) 
			{$_SESSION['name_error']=
				 "<font size=\"2\" color=\"#ff0000\">* Neįvestas vartotojo vardas</font>";
			 "";
			 return false;}
            elseif (!preg_match("/^([0-9a-zA-Z])*$/", $username))  /* Check if username is not alphanumeric */ 
			{$_SESSION['name_error']=
				"<font size=\"2\" color=\"#ff0000\">* Vartotojo vardas gali būti sudarytas<br>
				&nbsp;&nbsp;tik iš raidžių ir skaičių</font>";
		     return false;}
	        else return true;
   }
             
 function checkpass($pwd,$dbpwd) {     //  slaptazodzio tikrinimas (tik demo: min 4 raides ir/ar skaiciai) ir ar sutampa su DB esanciu
	   if (!$pwd || strlen($pwd = trim($pwd)) == 0) 
			{$_SESSION['pass_error']=
			  "<font size=\"2\" color=\"#ff0000\">* Neįvestas slaptažodis</font>";
			 return false;}
            elseif (!preg_match("/^([0-9a-zA-Z])*$/", $pwd))  /* Check if $pass is not alphanumeric */ 
			{$_SESSION['pass_error']="* Čia slaptažodis gali būti sudarytas<br>&nbsp;&nbsp;tik iš raidžių ir skaičių";
		     return false;}
            elseif (strlen($pwd)<4)  // per trumpas
			         {$_SESSION['pass_error']=
						  "<font size=\"2\" color=\"#ff0000\">* Slaptažodžio ilgis <4 simbolius</font>";
		              return false;}
	          elseif ($dbpwd != substr(hash( 'sha256', $pwd ),5,32))
               {$_SESSION['pass_error']=
				   "<font size=\"2\" color=\"#ff0000\">* Neteisingas slaptažodis</font>";
                return false;}
            else return true;
   }

 function checkdb($username) {  // iesko DB pagal varda, grazina {vardas,slaptazodis,lygis,id} ir nustato name_error
		 $db=mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);
		 $sql = "SELECT * FROM " . TBL_USERS. " WHERE slapyvardis = '$username'";
		 $result = mysqli_query($db, $sql);
	     $uname = $upass = null;
		 if (!$result || (mysqli_num_rows($result) != 1))   // jei >1 tai DB vardas kartojasi, netikrinu, imu pirma
	  	 {  // neradom vartotojo DB
		    $_SESSION['name_error']=
			 "<font size=\"2\" color=\"#ff0000\">* Tokio vartotojo nėra</font>";
         }
      else {  //vardas yra DB
           $row = mysqli_fetch_assoc($result); 
           $uname= $row["slapyvardis"]; $upass= $row["slaptazodis"]; 
           $ulevel=$row["vartotojo_lygis"];}
     return array($uname,$upass,$ulevel);
 }

function checkdbtitle($title, $name) {  // iesko DB pagal varda, grazina {vardas,slaptazodis,lygis,id} ir nustato name_error
		 $db=mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);
		 $sql = "SELECT * FROM " . TBL_TESTAI. " WHERE pavadinimas = '$title' AND testo_sudarytojas = '$name'";
		 $result = mysqli_query($db, $sql);
	     $titlename = $sudar = null;
		 if (!$result || (mysqli_num_rows($result) != 1))   // jei >1 tai DB vardas kartojasi, netikrinu, imu pirma
	  	 {  // neradom vartotojo DB
		    $_SESSION['title_error']=
			 "<font size=\"2\" color=\"#ff0000\">* Tokio testo nėra</font>";
         }
      else {  //vardas yra DB
           $row = mysqli_fetch_assoc($result); 
           $titlename= $row["pavadinimas"]; $sudar= $row["testo_sudarytojas"]; }
     return array($titlename,$sudar);
 }

function checkdbquestion($question, $name) {  // iesko DB pagal varda, grazina {vardas,slaptazodis,lygis,id} ir nustato name_error
		 $db=mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);
		 $sql = "SELECT * FROM " . TBL_KLAUSIMAI. " WHERE klausimas = '$question' AND testo_pavadinimas = '$name'";
		 $result = mysqli_query($db, $sql);
	     $klausname = $pav = null;
		 if (!$result || (mysqli_num_rows($result) != 1))   // jei >1 tai DB vardas kartojasi, netikrinu, imu pirma
	  	 {  // neradom vartotojo DB
		    $_SESSION['question_error']=
			 "<font size=\"2\" color=\"#ff0000\">* Tokio klausimo nėra</font>";
         }
      else {  //vardas yra DB
           $row = mysqli_fetch_assoc($result); 
           $klausname= $row["klausimas"]; $pav= $row["testo_pavadinimas"]; }
     return array($klausname,$pav);
 }

 ?>
 