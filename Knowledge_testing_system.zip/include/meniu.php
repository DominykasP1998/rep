<?php
// meniu.php  rodomas meniu pagal vartotojo rolę

if (!isset($_SESSION)) { header("Location: logout.php");exit;}
include("include/nustatymai.php");
$user=$_SESSION['user'];
$userlevel=$_SESSION['ulevel'];
$role="";
{foreach($user_roles as $x=>$x_value)
			      {if ($x_value == $userlevel) $role=$x;}
} 

     echo "<table width=100% border=\"0\" cellspacing=\"1\" cellpadding=\"3\" class=\"meniu\">";
        echo "<tr><td>";
        echo "Prisijungęs vartotojas: <b>".$user."</b>     Rolė: <b>".$role."</b> <br>";
        echo "</td></tr><tr><td>";
        echo "[<a class=\"link\" href=\"useredit.php\">Slaptažodžio keitimas</a>] &nbsp;&nbsp;";

        if ($userlevel == $user_roles["Studentas"])
		{
        echo "[<a class=\"link\" href=\"testlist.php\">Tavo testai</a>] &nbsp;&nbsp;";
		}
     //Trečia operacija tik rodoma pasirinktu kategoriju vartotojams, pvz.:
        if (($userlevel == $user_roles["Dėstytojas"]))
			{
            echo "[<a class=\"link\" href=\"kurti.php\">Kurti testą</a>] &nbsp;&nbsp;";
		    echo "[<a class=\"link\" href=\"modifikuoti.php\">Modifikuoti testą</a>] &nbsp;&nbsp;";
		    echo "[<a class=\"link\" href=\"testperziura.php\">Peržiūrėti spręstų testų įvertinimus</a>] &nbsp;&nbsp;";
       		}   
        //Administratoriaus sąsaja rodoma tik administratoriui
        if ($userlevel == $user_roles[ADMIN_LEVEL] ) {
            echo "[<a class=\"link\" href=\"admin.php\">Administratoriaus sąsaja</a>] &nbsp;&nbsp;";
        }
        echo "[<a class=\"link\" href=\"logout.php\">Atsijungti</a>]";
      echo "</td></tr></table>";
?>       
    
 