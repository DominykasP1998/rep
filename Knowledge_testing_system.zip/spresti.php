<?php
session_start();

include("include/nustatymai.php");
include("include/functions.php");


// cia sesijos kontrole
if (!isset($_SESSION['prev']) || ($_SESSION['ulevel'] != $user_roles[STUDENT_LEVEL]) || (($_SESSION['prev'] != "testlist") && ($_SESSION['prev'] != "spresti")))
{ header("Location: logout.php");exit;}

$_SESSION['testnews'] = "";

$_SESSION['namespr'] = $_GET['name'];
$_SESSION['autspr'] = $_GET['author'];

$name = $_SESSION['namespr'];

$sudar = $_SESSION['autspr'];

$_SESSION['prev'] = "spresti";
?>

<html>
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=9; text/html; charset=utf-8">
        <title>Testo sprendimas</title>
        <link href="include/styles.css" rel="stylesheet" type="text/css" >
    </head>
    <body>
        <table class="center" ><tr><td>
			<center><h1>Žinių testavimo sistema</h1></center>
			<center>Dominykas Pašukys IFB7</center><br/>
        </td></tr><tr><td>

			<?php
			
			  echo "<div align=\"center\">";echo "<font size=\"4\" color=\"#ff0000\">".$_SESSION['testnews'] . "<br></font>";   
			?>
			<?php
			 $db=mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);

			 $sql = "SELECT * FROM " . TBL_KLAUSIMAI. " WHERE testo_pavadinimas = '$name'";
			
			 $result = mysqli_query($db, $sql);
			?>
			 <?php echo "<table class=\"center\"><tr><td>"; $i = 0;?> 
            <?php while($row = mysqli_fetch_assoc($result)) { 
				 $klaus = $row['klausimas'];
                 $vert = $row['verte_balais'];
	             $i = $i + 1;
			?>
			<form action="procspresti.php" method="POST" class="login">             
        <center style="font-size:18pt;"><b>Klausimas nr. <?php echo $i; ?></b></center>
        <p style="text-align:left;">Klausimas: <?php echo $klaus; echo " "; echo "($vert balai.)"; ?><br></p>
			<p style="text-align:left;">Atsakymas:<br>
            <input class ="s1" name="<?php echo "atsakymas$i"; ?>" type="text"/><br>
        </p>
			<?php } ?>
			   <p style="text-align:left;">
            <input type="submit" name="finish" value="Baigti"/>     
              </p>
			</form>
			<?php echo "</td></tr></table></div><br>"; ?>
			<?php echo "<p align=\"center\">[<a class=\"link\" href=\"testlist.php?name=$name&author=$sudar\">Atgal</a>]</p>"; ?>

			
	</body>
</html>