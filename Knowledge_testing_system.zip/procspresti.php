<?php
session_start();

include("include/nustatymai.php");
include("include/functions.php");

// cia sesijos kontrole
if (!isset($_SESSION['prev']) || ($_SESSION['ulevel'] != $user_roles[STUDENT_LEVEL]) || (($_SESSION['prev'] != "spresti") && ($_SESSION['prev'] != "procspresti")))
{ header("Location: logout.php");exit;}

$_SESSION['testnews']="";

$_SESSION['prev']="procspresti";

$name = $_SESSION['namespr'];
$sudar = $_SESSION['autspr'];
$username=$_SESSION['user'];

$db=mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);

$klaus = "SELECT * FROM " . TBL_KLAUSIMAI. " WHERE testo_pavadinimas = '$name'";

$result = mysqli_query($db, $klaus);

$i = 0;
$maxverte = 0;
$uzdirbo = 0;

while($row = mysqli_fetch_assoc($result))
{
    $i++;
	$var = "atsakymas$i";
	$ats = trim($row['atsakymas']);
	$verte = $row['verte_balais'];
	$maxverte = $maxverte + $verte;
	$studats = strtolower(trim($_POST[$var]));
	if ($studats == $ats)
	{
		$uzdirbo = $uzdirbo + $verte;
	}
}

$dbv=mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);

 $reqname = "SELECT slapyvardis FROM " . TBL_USERS. " WHERE slapyvardis = '$username'";
		 
$resultas = mysqli_query($dbv, $reqname);
		 
$roww = mysqli_fetch_assoc($resultas);
		 
 $useris = $roww['slapyvardis'];

$reqdest = "SELECT testo_sudarytojas FROM " . TBL_TESTAI. " WHERE pavadinimas = '$name'";

$destname = mysqli_query($dbv, $reqdest);

$rowww = mysqli_fetch_assoc($destname);

$destvardas = $rowww['testo_sudarytojas'];

 $sql = "INSERT INTO " . TBL_SPR. " (gautas_ivertis, autorius, testo_pavadinimas, laikas, testo_kurejas)
          VALUES ('$uzdirbo', '$useris', '$name', NOW(), '$destvardas')";
				   
		 if (mysqli_query($dbv, $sql))
		      {$_SESSION['testnews']="Testas '$name' užbaigtas sėkmingai. Surinkote '$uzdirbo' balus iš '$maxverte' galimų.";
			   $_SESSION['maxbalai'] = $maxverte;
			   header("Location:testlist.php?name=$name&author=$sudar"); exit;
			  }
         else {$_SESSION['testnews']="Testo užbaigti nepavyko:" . $sql . "<br>" . mysqli_error($dbv);}
				  

?>