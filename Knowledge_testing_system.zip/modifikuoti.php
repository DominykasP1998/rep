<?php
// admin.php
// vartotojų įgaliojimų keitimas ir naujo vartotojo registracija, jei leidžia nustatymai
// galima keisti vartotojų roles, tame tarpe uzblokuoti ir/arba juos pašalinti
// sužymėjus pakeitimus į procadmin.php, bus dar perklausta

session_start();
include("include/nustatymai.php");
include("include/functions.php");
// cia sesijos kontrole
if (!isset($_SESSION['prev']) || ($_SESSION['ulevel'] != $user_roles[TEACHER_LEVEL]) || (($_SESSION['prev'] != "index") && ($_SESSION['prev'] != "modifikuoti") && ($_SESSION['prev'] != "editname") && ($_SESSION['prev'] != "salinimas") && ($_SESSION['prev'] != "editquestion") && ($_SESSION['prev'] != "procedit")))
{ header("Location: logout.php");exit;}

$_SESSION['prev']="modifikuoti";

?>

<html>
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=9; text/html; charset=utf-8">
        <title>Testų modifikavimas</title>
        <link href="include/styles.css" rel="stylesheet" type="text/css" >
    </head>
    <body>
        <table class="center" ><tr><td>
			<center><h1>Žinių testavimo sistema</h1></center>
            </td></tr><tr><td>
		<center><font size="5">Testų šalinimas, pavadinimo keitimas, veiksmai su klausimais</font></center></td></tr></table> <br>
		<center><b><?php echo $_SESSION['messageedit']; $_SESSION['messageedit'] = ""; ?></b></center>
	
	    <table class="center" style=" width:75%; border-width: 3px; border-style: dashed; border-color: black;">
			<tr><td width=100%><center><a class="link" href="index.php">[Atgal į pradžią]</a></center></td><td width=100%></tr></table> <br> 
		    
<?php
    $sudare = $_SESSION['user'];
	$db=mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);
		$reqname = "SELECT slapyvardis FROM " . TBL_USERS. " WHERE slapyvardis = '$sudare'";
		 
		 $resultas = mysqli_query($db, $reqname);
		 
		 $roww = mysqli_fetch_assoc($resultas);
		 
		 $useris = $roww['slapyvardis'];
	$sql = "SELECT pavadinimas, testo_sudarytojas "
            . "FROM " . TBL_TESTAI . " WHERE testo_sudarytojas = '$useris'";
	$result = mysqli_query($db, $sql);
	if (!$result || (mysqli_num_rows($result) < 1))  
			{echo "Testų kolkas nesukūrėte."; exit;}
?>
    <table class="center"  border="1" cellspacing="0" cellpadding="3">
    <tr><td><center><b>Testo pavadinimas</b></center></td><td><center><b>Kūrėjas</b></center></td><td><center><b>Keisti pavadinimą?</b></center></td><td><center><b>Šalinimas</b></center></td><td><center><b>Redaguoti klausimus?</b></center></td></tr>
<?php
        while($row = mysqli_fetch_assoc($result)) 
	{	 
	    $pav=$row['pavadinimas'];
	  	$creator= $row['testo_sudarytojas'];
      	echo "<tr><td><center>".$pav. "</center></td>";
    	echo "<td><center>".$creator. "</center></td>";
        echo "<td><center><a class=\"link\" href=\"editname.php?name=$pav\">Keisti pavadinimą</a></center></td>";  
        echo "<td><center><a class=\"link\" href=\"salinimas.php?name=$pav\">Pašalinti</a></center></td>";
		echo "<td><center><a class=\"link\" href=\"editquestion.php?name=$pav\">Klausimai</a></center></td></tr>";
   }
?>
        </table>
    </body></html>
