<?php
session_start();
include("include/nustatymai.php");
include("include/functions.php");
// cia sesijos kontrole
if (!isset($_SESSION['prev']) || (($_SESSION['prev'] != "kurti")) && ($_SESSION['prev'] != "proccreate"))
{ header("Location: logout.php");exit;}

$_SESSION['message']="";

$_SESSION['title_error']="";
$_SESSION['question_error']="";
$_SESSION['answer_error']="";
$_SESSION['worth_error']="";

//$_SESSION['question']=$question;
//$_SESSION['answer']=$answer;
//$_SESSION['worth']=$worth;

$title=strtolower($_POST['pavadinimas']);
$_SESSION['title']=$title;

$question=strtolower($_POST['klausimas']);
$_SESSION['question']=$question;

$answer=strtolower($_POST['atsakymas']);
$_SESSION['answer']=$answer;

$worth=$_POST['verte'];
$_SESSION['worth']=$worth;

$username=$_SESSION['user'];

$_SESSION['prev'] = "proccreate";

        if (checktesttitle($title))
		{ 
     
		 list($dbtitle)=checkdbtitle($title, $username);  //patikrinam DB       
         if ($dbtitle)  {  // jau yra toks vartotojas DB
		     $_SESSION['title_error']= 
				 "<font size=\"2\" color=\"#ff0000\">* Testą tokiu pavadinimu jau esate sukūręs</font>";
				 }
         else {
			   $_SESSION['title_error']= "";
		       if (checktestquestion($question) && checktestanswer($answer) && checktestworth($worth)) // antra tikrinimo dalis checkpass bus true
			{ 

		 $db=mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);
				   
		 $reqname = "SELECT slapyvardis FROM " . TBL_USERS. " WHERE slapyvardis = '$username'";
		 
		 $result = mysqli_query($db, $reqname);
		 
		 $row = mysqli_fetch_assoc($result);
		 
		 $useris = $row['slapyvardis'];
				   
		 $sql = "INSERT INTO " . TBL_TESTAI. " (pavadinimas, testo_sudarytojas)
          VALUES ('$title', '$useris')";
		 
		 $klaus = "INSERT INTO " . TBL_KLAUSIMAI. " (klausimas, atsakymas, verte_balais, testo_pavadinimas)
		    VALUES ('$question', '$answer', '$worth', '$title')";
				   
		 if (mysqli_query($db, $sql) && mysqli_query($db, $klaus)) 
		      {$_SESSION['message']="Testas '$title' sukurtas sėkmingai";}
         else {$_SESSION['message']="Testo sukurti nepavyko:" . $sql . "<br>" . mysqli_error($db);}
         
             header("Location:kurti.php"); exit;
				    
          }
		}
		}
        // griztam taisyti
         // session_regenerate_id(true);
          header("Location:kurti.php");exit;
?>