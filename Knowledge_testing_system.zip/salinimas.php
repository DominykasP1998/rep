<?php
session_start();

include("include/nustatymai.php");
include("include/functions.php");

// cia sesijos kontrole
if (!isset($_SESSION['prev']) || ($_SESSION['ulevel'] != $user_roles[TEACHER_LEVEL]) || (($_SESSION['prev'] != "modifikuoti") && ($_SESSION['prev'] != "salinimas")))
{ header("Location: logout.php");exit;}

$_SESSION['prev'] = "salinimas";
$_SESSION['messageedit']="";
$username = $_SESSION['user'];

$name = $_GET['name'];

         $db=mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);

        $reqname = "SELECT testo_sudarytojas FROM " . TBL_TESTAI ." WHERE pavadinimas = '$name'";
	    $rez = mysqli_query($db, $reqname);
	    $roww = mysqli_fetch_assoc($rez);
	    $namee = $roww['testo_sudarytojas'];
	if ($username != $namee) {header("Location: logout.php");exit; }	
				   
		 $klausdelete = "DELETE FROM " . TBL_KLAUSIMAI. " WHERE testo_pavadinimas = '$name'";
		 				   
		 $sql = "DELETE FROM " . TBL_TESTAI. " WHERE pavadinimas = '$name'";
		 
				   
		 if (mysqli_query($db, $klausdelete) && mysqli_query($db, $sql)) 
		      {$_SESSION['messageedit']="Testas '$name' ištrintas su visais klausimais sėkmingai.";}
         else {$_SESSION['messageedit']="Klaida šalinant testą:" . $sql . "<br>" . mysqli_error($db);}
         
             header("Location:modifikuoti.php"); exit;
?>