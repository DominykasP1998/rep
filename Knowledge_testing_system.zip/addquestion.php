<?php

session_start();

include("include/nustatymai.php");
include("include/functions.php");

if (!isset($_SESSION['prev']) || ($_SESSION['ulevel'] != $user_roles[TEACHER_LEVEL]) || (($_SESSION['prev'] != "editquestion") && ($_SESSION['prev'] != "addquestion") && ($_SESSION['prev'] != "procaddquestion")))
{ header("Location: logout.php");exit;}

$_SESSION['prev'] = "addquestion";

$name = $_SESSION['namedit'];

?>

<html>
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=9; text/html; charset=utf-8">
        <title>Žinių testavimo sistema</title>
        <link href="include/styles.css" rel="stylesheet" type="text/css" >
    </head>
    <body>
        <table class="center" ><tr><td>
			<center><h1>Žinių testavimo sistema</h1></center>
			<center>Dominykas Pašukys IFB7</center><br/>
        </td></tr><tr><td>

			
			 <?php echo "<div align=\"center\">"; if (!empty($_SESSION['messageedit'])) echo "<font size=\"4\" color=\"#ff0000\">".$_SESSION['messageedit'] . "<br></font>"; ?>
			
			<?php  echo "<table class=\"center\"><tr><td>"; ?>
			
			<form action="procaddquestion.php" method="POST" class="login" charset="utf-8">             
        <center style="font-size:18pt;"><b>Naujo klausimo kūrimas</b></center>
				
        <p style="text-align:left;">Klausimas:<br>
            <input class ="s1" name="klausimas" type="text" value="<?php echo $_SESSION['question'];  ?>"/><br>
          <?php echo $_SESSION['question_error']; 
			?>
        </p> 
	    <p style="text-align:left;">Atsakymas:<br>
            <input class ="s1" name="atsakymas" type="text" value="<?php echo $_SESSION['answer'];  ?>"/><br>
          <?php echo $_SESSION['answer_error']; 
			?>
        </p>
	    <p style="text-align:left;">Vertė balais:<br>
            <input class ="s1" name="verte" type="number" value="0" value="<?php echo $_SESSION['worth'];  ?>"/><br>
			<?php echo $_SESSION['worth_error']; 
			?>
        </p>  
        <p style="text-align:left;">Testas: <?php echo $name ?><br>
				</p>	
        <p style="text-align:left;">
            <input type="submit" name="add" value="Pridėti"/>     
        </p>
    </form>
            <?php  echo "</td></tr></table></div><br>"; ?>
			<?php echo "<p align=\"center\">[<a class=\"link\" href=\"editquestion.php?name=$name\">Atgal</a>]</p>"; ?>

	</body>
</html>