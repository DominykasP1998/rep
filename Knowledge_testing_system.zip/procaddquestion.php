<?php
session_start();

include("include/nustatymai.php");
include("include/functions.php");

// cia sesijos kontrole
if (!isset($_SESSION['prev']) || ($_SESSION['ulevel'] != $user_roles[TEACHER_LEVEL]) || (($_SESSION['prev'] != "editquestion") && ($_SESSION['prev'] != "addquestion")))
{ header("Location: logout.php");exit;}


$_SESSION['messageedit']="";

$_SESSION['question_error']="";
$_SESSION['answer_error']="";
$_SESSION['worth_error']="";

//$_SESSION['question']=$question;
//$_SESSION['answer']=$answer;
//$_SESSION['worth']=$worth;

$question=strtolower($_POST['klausimas']);
$_SESSION['question']=$question;

$answer=strtolower($_POST['atsakymas']);
$_SESSION['answer']=$answer;

$worth=$_POST['verte'];
$_SESSION['worth']=$worth;

$name = $_SESSION['namedit'];

$username = $_SESSION['user'];

$_SESSION['prev'] = "procaddquestion";

        if (checktestquestion($question))
		{ 
     
		 list($dbquestion)=checkdbquestion($question, $name);  //patikrinam DB       
         if ($dbquestion)  {  // jau yra toks vartotojas DB
		     $_SESSION['question_error']= 
				 "<font size=\"2\" color=\"#ff0000\">* Toks klausimas jau yra šiame teste</font>";
				 }
         else {
			   $_SESSION['question_error']= "";
		       if (checktestanswer($answer) && checktestworth($worth)) // antra tikrinimo dalis checkpass bus true
			{ 

		 $db=mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);								  
		 
		$reqname = "SELECT testo_sudarytojas FROM " . TBL_TESTAI ." WHERE pavadinimas = '$name'";
	    $rez = mysqli_query($db, $reqname);
	    $roww = mysqli_fetch_assoc($rez);
	    $namee = $roww['testo_sudarytojas'];
	if ($username != $namee) {header("Location: logout.php");exit; }
				   
		 $sql = "INSERT INTO " . TBL_KLAUSIMAI. " (klausimas, atsakymas, verte_balais, testo_pavadinimas)
		    VALUES ('$question', '$answer', '$worth', '$name')";
				   
		 if (mysqli_query($db, $sql)) 
		      {$_SESSION['messageedit']="Klausimas '$question' pridėtas sėkmingai";}
         else {$_SESSION['messageedit']="Klausimo pridėti nepavyko:" . $sql . "<br>" . mysqli_error($db);}
         
             header("Location:editquestion.php?name=$name"); exit;
				    
          }
		}
		}
        // griztam taisyti
         // session_regenerate_id(true);
          header("Location:addquestion.php");exit;
?>