<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\pokalbiui;
use App\Models\uzregistravimas;
use App\Models\zinutes_rasymas;
use App\Models\atsiliepimo_rasymas;

class klientoC extends Controller
{
    function prekiu()
    {
        $prekes = DB::table('prekes')->select('*')->paginate(6);
        return view('klientas.prekiu_sarasas', ['prekes' => $prekes]);
    }

    function norai()
    {
        $prekes = DB::table('prekes')->select('*')->where('kieno_noru_sarase', session('LoggedUser'))->paginate(6);
        return view('klientas.noru_sarasas', ['prekes' => $prekes]);
    }

    function formuotiUžsakymąN($id)
    {
        $preke = DB::table('prekes')->select('*')->where('id', $id)->first();
        return view('Klientas.prekes_uzsakymasN', ['id', $id], ['preke' => $preke]);
    }

    function formuotiN(Request $request)
    {
        $request->validate(
            [
                'adresas' => 'required',
                'miestas' => 'required',
                'kodas' => 'required|min:5|max:5'
            ],

            [
                'adresas.required' => 'Turite nurodyti pristatymo adresą.',
                'miestas.required' => 'Turite nurodyti miestą.',
                'kodas.required' => 'Turite nurodyti pašto kodą.',
                'kodas.min' => 'Kodas turi būti penkių skaitmenų.',
                'kodas.max' => 'Kodas turi būti penkių skaitmenų.'
            ]
        );

        if ($request->budas == "mb") {
            return back()->with('Klaida', 'Nenurodytas mokėjimo būdas.');
        } else {
            return redirect()->route('norai')->with('Sėkmė', 'Užsakymas pateiktas sėkmingai.');
        }
    }

    function formuotiUžsakymąS($id)
    {
        $preke = DB::table('prekes')->select('*')->where('id', $id)->first();
        return view('Klientas.prekes_uzsakymasS', ['id', $id], ['preke' => $preke]);
    }

    function formuotiS(Request $request)
    {
        $request->validate(
            [
                'adresas' => 'required',
                'miestas' => 'required',
                'kodas' => 'required|min:5|max:5'
            ],

            [
                'adresas.required' => 'Turite nurodyti pristatymo adresą.',
                'miestas.required' => 'Turite nurodyti miestą.',
                'kodas.required' => 'Turite nurodyti pašto kodą.',
                'kodas.min' => 'Kodas turi būti penkių skaitmenų.',
                'kodas.max' => 'Kodas turi būti penkių skaitmenų.'
            ]
        );

        if ($request->budas == "mb") {
            return back()->with('Klaida', 'Nenurodytas mokėjimo būdas.');
        } else {
            return redirect()->route('prekiu')->with('Sėkmė', 'Užsakymas pateiktas sėkmingai.');
        }
    }

    function naikintiNorą($id)
    {
        DB::update('update prekes set kieno_noru_sarase = ? where id = ?', ["-", $id]);
        return back()->with('Sėkmė', 'Prekė pašalinta iš sąrašo.');
    }

    function pridėtiNorą($id)
    {
        DB::update('update prekes set kieno_noru_sarase = ? where id = ?', [session('LoggedUser'), $id]);
        return back()->with('Sėkmė', 'Prekė sėkmingai pridėta į Jūsų norų sąrašą.');
    }

    function pokalbiui()
    {
        return view('klientas.pokalbiui');
    }

    function patarimai()
    {
        return view('klientas.patarimai');
    }

    function gautiPatarimus(Request $request)
    {
        $data = DB::table('patarimai')->select('simptomas')->where('kas_sugedo', $request->kas_sugedo)->distinct()->get();
        return response()->json($data);
    }

    function peržiūrėtiPatarimus(Request $request)
    {
        if ($request->kas_sugedo == "kas") {
            return back()->with('Klaida', 'Nepasirinkta, kas sugedo.');
        } else if ($request->simptomas == "simp") {
            return back()->with('Klaida', 'Nepasirinktas simptomas.');
        } else {

            $patarimai = DB::table('patarimai')->select('*')->where('kas_sugedo', $request->kas_sugedo)->where('simptomas', $request->simptomas)->paginate(5);
            return view('klientas.patarimu_s', ['patarimai' => $patarimai]);
        }
    }

    function siūlomiServeriai(Request $request)
    {
        if ($request->poreikis == "pas") {
            return back()->with('Klaida', 'Nepasirinktas poreikis.');
        } else {
            $serveriai = DB::table('serveriai')->select('*')->where('poreikis', $request->poreikis)->paginate(6);
            return view('Klientas.siulomi_serveriai', ['serveriai' => $serveriai]);
        }
    }

    function užsakytiS(Request $request)
    {
        $request->validate(
            [
                'kiekis' => 'required'
            ],

            [
                'kiekis.required' => 'Nenurodytas kiekis.'
            ]
        );
            return view('Klientas.serverio_uzsakymas', ['pas' => $request->pasirinkimas]);
    }

    function užsakytiSer(Request $request)
    {
        $request->validate(
            [
                'adresas' => 'required',
                'miestas' => 'required',
                'kodas' => 'required|min:5|max:5'
            ],

            [
                'adresas.required' => 'Turite nurodyti pristatymo adresą.',
                'miestas.required' => 'Turite nurodyti miestą.',
                'kodas.required' => 'Turite nurodyti pašto kodą.',
                'kodas.min' => 'Kodas turi būti penkių skaitmenų.',
                'kodas.max' => 'Kodas turi būti penkių skaitmenų.'
            ]
        );

        if ($request->budas == "mb") {
            return redirect()->route('serveriai')->with('Klaida', 'Nenurodytas mokėjimo būdas.');
        } else {
            return redirect()->route('serveriai')->with('Sėkmė', 'Užsakymas pateiktas sėkmingai.');
        }
    }

    function atsiliepimai_k()
    {
        $atsiliepimai = DB::table('atsiliepimai')->select('*')->paginate(10);
        $vadybininkai = DB::table('registruoti_vartotojai')->select('*')->where('role', 'Vadybininkas');
        $konsultantai = DB::table('registruoti_vartotojai')->select('*')->where('role', 'Konsultantas');
        $prekės = DB::table('prekes')->select('*');
        return view('klientas.atsiliepimai_k', ['atsiliepimai' => $atsiliepimai, 'vadybininkai' => $vadybininkai, 'konsultantai' => $konsultantai, 'prekės' => $prekės]);
    }

    function rasyti_atsiliepima(Request $request)
    {
        $request->validate(

            [
                'ats' => 'required|max:200'
            ],

            [
                'ats.required' => 'Įveskite atsiliepimą.',
                'ats.max' => 'Atsiliepimas negali viršyti 200 simbolių.'
            ]

        );

        if ($request->tipas == 'Apie') {

            return back()->with('Klaida', 'Nepasirinkote, apie ką bus atsiliepimas.');
        } else {

            $vart_id = DB::table('registruoti_vartotojai')->select('id')->where('prisijungimo_vardas', session('LoggedUser'))->first();

            $tipobj = $request->tipas . " " . $request->objektas;

            $ras = new atsiliepimo_rasymas;
            $ras->tipas = $tipobj;
            $ras->atsiliepimas = $request->ats;
            $ras->prisijungimo_vardas = session('LoggedUser');
            $ras->fk_REGISTRUOTI_VARTOTOJAIid = $vart_id->id;
            $patikrinti = $ras->save();

            if ($patikrinti) {
                return back()->with('Sėkmė', 'Atsiliepimas sėkmingai pateiktas.');
            } else {
                return back()->with('Klaida', 'Atsiliepimo pateikti nepavyko.');
            }
        }
    }

    function gautiKonsultantus(Request $request)
    {
        $data = DB::table('registruoti_vartotojai')->select('*')->where('role', $request->role)->get();
        return response()->json($data);
    }

    function gautiVadybininkus(Request $request)
    {
        $data = DB::table('registruoti_vartotojai')->select('*')->where('role', $request->role)->get();
        return response()->json($data);
    }

    function gautiPrekes()
    {
        $data = DB::table('prekes')->select('pavadinimas')->get();
        return response()->json($data);
    }

    function serveriai()
    {
        $select = DB::table('serveriai')->select('poreikis');
        return view('klientas.serveriai', ['select' => $select]);
    }

    function forumas_k()
    {
        $temos = DB::table('forumo_temos')->select('*')->paginate(10);
        return view('klientas.forumas_k', ['temos' => $temos]);
    }

    function zinutes_k($id)
    {
        $zinutes = DB::table('forumo_zinutes')->select('*')->where('fk_FORUMO_TEMOSid', $id)->paginate(10);
        $pavadinimas = DB::table('forumo_temos')->select('*')->where('id', $id)->first();
        $zin_count = DB::table('forumo_zinutes')->select('*')->where('fk_FORUMO_TEMOSid', $id)->count();
        return view('klientas.forumo_zinutes', ['zinutes' => $zinutes], ['pavadinimas' => $pavadinimas], ['zin_count' => $zin_count]);
    }

    function rasyti_zinute(Request $request, $id)
    {

        $request->validate(

            [
                'zin' => 'required|max:200'
            ],

            [
                'zin.required' => 'Įveskite žinutę.',
                'zin.max' => 'Žinutė negali viršyti 200 simbolių.'
            ]

        );

        $vart_id = DB::table('registruoti_vartotojai')->select('id')->where('prisijungimo_vardas', session('LoggedUser'))->first();

        $ras = new zinutes_rasymas;
        $ras->prisijungimo_vardas = session('LoggedUser');
        $ras->zinute = $request->zin;
        $ras->fk_FORUMO_TEMOSid = $id;
        $ras->fk_REGISTRUOTI_VARTOTOJAIid = $vart_id->id;
        $patikrinti = $ras->save();

        if ($patikrinti) {
            return back()->with('Sėkmė', 'Žinutė sėkmingai parašyta.');
        } else {
            return back()->with('Klaida', 'Žinutės nepavyko parašyti.');
        }
    }

    function uzregistruoti_p(Request $request)
    {


        $kon = "Konsultantas";
        $val = $request->input('valandos');
        $min = $request->input('minutes');
        $date = $request->input('date');
        $laikas = $val . $min;

        $konsv = DB::table('registruoti_vartotojai')->select('vardas')->where('role', $kon)->first();
        $konsp = DB::table('registruoti_vartotojai')->select('pavarde')->where('role', $kon)->first();
        $konsid = DB::table('registruoti_vartotojai')->select('id')->where('role', $kon)->first();
        $klientov = DB::table('registruoti_vartotojai')->select('vardas')->where('prisijungimo_vardas', session('LoggedUser'))->first();
        $klientop = DB::table('registruoti_vartotojai')->select('pavarde')->where('prisijungimo_vardas', session('LoggedUser'))->first();
        $registr = DB::table('uzregistruoti_pokalbiai')->select('data', 'laikas')->where('data', $date)->where('laikas', $laikas)->count();

        if ($date == "") {
            return back()->with('Klaida', 'Privalote pasirinkti datą!');
        } else if ($val == "v") {
            return back()->with('Klaida', 'Privalote pasirinkti valandą!');
        } else if ($min == "m") {
            return back()->with('Klaida', 'Privalote pasirinkti minutes!');
        } else if ($registr == 1) {
            return back()->with('Klaida', 'Šis laikas šią dieną jau užimtas.');
        } else {

            DB::insert('insert into uzregistruoti_pokalbiai (kliento_vardas, kliento_pavarde, konsultanto_vardas, konsultanto_pavarde, data, laikas, fk_REGISTRUOTI_VARTOTOJAIid)
            values (?, ?, ?, ?, ?, ?, ?)', [$klientov->vardas, $klientop->pavarde, $konsv->vardas, $konsp->pavarde, $date, $laikas, $konsid->id]);

            return back()->with('Sekme', 'Sėkmingai užsiregistravote.');
        }
    }
}
