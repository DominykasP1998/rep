<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\pardavimu_pateikimas;

class vadC extends Controller
{
    function segmentavimas()
    {
        return view('vadybininkas.segmentavimas');
    }

    function prekes()
    {
        $prekes = DB::table('prekes')->select('*')->paginate(6);
        return view('vadybininkas.prekes', ['prekes' => $prekes]);
    }

    function gautiPrekID($id)
    {
        $prek = DB::table('prekes')->select('*')->where('id', $id)->first();
        return view('vadybininkas.nuolaida', ['prek' => $prek]);
    }

    function pasiūlytiPrekę($id)
    {
        $prekes = DB::table('prekes')->select('*')->paginate(6);
        return view('vadybininkas.prekes_siulymas', ['id' => $id], ['prekes' => $prekes]);
    }

    function siūlyti($id)
    {
        return redirect()->route('prisijunge')->with('Sėkmė', 'Prekė pasiūlyta sėkmingai.');
    }

    function nustatytiNuolaidą(Request $request, $id)
    {
        $request->validate(
            [
                'n_dydis' => 'required'
            ],

            [
                'n_dydis.required' => 'Neįvestas nuolaidos dydis.'
            ]
        );

        if (($request->n_dydis < 5) && ($request->n_dydis > 0)) {
            return back()->with('Klaida', 'Nuolaida negali būti mažesnė nei 5 procentai.');
        } else if ($request->n_dydis > 99) {
            return back()->with('Klaida', 'Nuolaida negali būti didesnė nei 99 procentai.');
        } else if ($request->n_dydis == 0) {
            DB::update('update prekes set ar_nuolaida = ? where id = ?', ['Ne', $id]);
            return redirect()->route('prekes')->with('Sėkmė', 'Nuolaida nustatyta sėkmingai.');
        } else {
            DB::update('update prekes set ar_nuolaida = ?, nuo_dydis_proc = ? where id = ?', ['Taip', $request->n_dydis, $id]);
            return redirect()->route('prekes')->with('Sėkmė', 'Nuolaida nustatyta sėkmingai.');
        }
    }


    function prisijunge()
    {
        $prisijunge = DB::table('prisijunge_klientai')->select('*')->where('role', 'Klientas')->paginate(10);
        return view('vadybininkas.prisijunge_klientai', ['prisijunge' => $prisijunge]);
    }

    function pardavimu()
    {
        $pateiktos = DB::table('pardavimu_ataskaitos')->select('*')->where('autorius', session('LoggedUser'))->paginate(10);
        $count = DB::table('pardavimu_ataskaitos')->select('*')->count();
        return view('vadybininkas.pardavimu_ataskaitos', ['pateiktos' => $pateiktos], ['count' => $count]);
    }

    function nauja_pard()
    {
        return view('vadybininkas.nauja_ataskaita');
    }

    function pateikti_pard(Request $request)
    {
        //tikrinimas 
        $request->validate(

            [

                'kiek_pasiule' => 'required',
                'kiek_uzsisake' => 'required',
                'uz' => 'required'

            ],

            [
                'kiek_pasiule.required' => 'Privalote nurodyti, kiek prekių pasiūlėte klientams.',
                'kiek_uzsisake.required' => 'Privalote nurodyti, kiek prekių klientai užsisakė.',
                'uz.required' => 'Privalote nurodyti visą pardavimų sumą.'
            ]

        );

        if ($request->kiek_pasiule > $request->kiek_uzsisake) {

            $id = DB::table('registruoti_vartotojai')->select('id')->where('prisijungimo_vardas', session('LoggedUser'))->first();

            //Į duomenų bazę

            $pat = new pardavimu_pateikimas();
            $pat->autorius = session('LoggedUser');
            $pat->kiek_pasiule = $request->kiek_pasiule;
            $pat->kiek_uzsisake = $request->kiek_uzsisake;
            $pat->pardavimo_suma = $request->uz;
            $pat->fk_REGISTRUOTI_VARTOTOJAIid = $id->id;
            $pateikti = $pat->save();

            if ($pateikti) {
                return redirect()->route('pardavimu')->with('Sekme', 'Pardavimų ataskaita sėkmingai pateikta.');
            } else {
                return redirect()->route('pardavimu')->with('Klaida', 'Pardavimų ataskaitos pateikti nepavyko.');
            }
        } else {
            return back()->with('Klaida', 'Negali būti daugiau užsisakiusiųjų klientų nei pasiūlėte prekes.');
        }
    }

    function gautiPardID($id)
    {
        $ataskaita = DB::table('pardavimu_ataskaitos')->select('*')->where('Id', $id)->first();
        return view('vadybininkas.pard_ataskaita', ['ataskaita' => $ataskaita]);
    }
}
