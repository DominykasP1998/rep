<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\pokalbiu_pateikimas;

class konC extends Controller
{
    function pokalbiu()
    {
        $pateiktos = DB::table('pokalbiu_ataskaitos')->select('*')->where('autorius', session('LoggedUser'))->paginate(10);
        $count = DB::table('pokalbiu_ataskaitos')->select('*')->count();
        return view('konsultantas.pokalbiu_ataskaitos', ['pateiktos' => $pateiktos], ['count' => $count]);
    }

    function zaidimai()
    {
        return view('konsultantas.zaidimai');
    }

    function nauja_p_ataskaita()
    {
        return view('konsultantas.nauja_ataskaita');
    }

    function pateikti(Request $request)
    {
        //tikrinimas 
        $request->validate(

            [

                'kv' => 'required|min:3|max:20',
                'kp' => 'required|min:3|max:20',
                'kpv' => 'required|min:4|max:20',
                'amzius' => 'required|max:3',
                'tel_nr' => 'required|regex:/(370)[0-9]{8}/',
                'miestas' => 'required',
                'trukme' => 'required|max:3',
                'busena' => 'required|max:50',

            ],

            [
                'kv.required' => 'Privalote nurodyti savo kliento vardą.',
                'kv.min' => 'Kliento vardas negali būti trumpesnis nei 3 raidės.',
                'kv.max' => 'Kliento vardas negali būti ilgesnis nei 20 raidžių.',
                'kp.required' => 'Privalote nurodyti kliento pavardę.',
                'kp.min' => 'Kliento pavardė negali būti trumpesnė nei 3 raidės.',
                'kp.max' => 'Kliento pavardė negali būti ilgesnė nei 20 raidžių.',
                'kpv.required' => 'Nenurodytas kliento prisijungimo vardas.',
                'kpv.min' => 'Prisijungimo vardas negali būti trumpesnis nei 4 simboliai.',
                'kpv.max' => 'Prisijungimo vardas negali būti ilgesnis nei 20 simbolių.',
                'miestas.required' => 'Nenurodytas miestas.',
                'amzius.required' => 'Nenurodytas amžius.',
                'amzius.max' => 'Amžius negali būti ilgesnis nei 3 skaičiai.',
                'tel_nr.required' => 'Nenurodytas telefono numeris.',
                'tel_nr.regex' => 'Blogas telefono numerio formatas.',
                'trukme.required' => 'Nenurodyta pokalbio trukmė.',
                'trukme.max' => 'Pokalbio trukmė negali viršyti 3 skaitmenų.',
                'busena.required' => 'Privalote nurodyti kliento būseną.',
                'busena.max' => 'Kliento būsenos laukelyje gali būti ne daugiau 50 simbolių.'
            ]

        );

        $id = DB::table('registruoti_vartotojai')->select('id')->where('prisijungimo_vardas', session('LoggedUser'))->first();

        //Į duomenų bazę

        $pat = new pokalbiu_pateikimas;
        $pat->autorius = session('LoggedUser');
        $pat->kliento_vardas = $request->kv;
        $pat->kliento_pavarde = $request->kp;
        $pat->prisijungimo_vardas = $request->kpv;
        $pat->amzius = $request->amzius;
        $pat->miestas = $request->miestas;
        $pat->tel_nr = $request->tel_nr;
        $pat->trukme = $request->trukme;
        $pat->kliento_busena = $request->busena;
        $pat->fk_REGISTRUOTI_VARTOTOJAIid = $id->id;
        $pateikti = $pat->save();

        if ($pateikti) {
            return redirect()->route('pokalbiu')->with('Sekme', 'Pokalbių ataskaita sėkmingai pateikta.');
        } else {
            return redirect()->route('pokalbiu')->with('Klaida', 'Pokalbių ataskaitos pateikti nepavyko.');
        }
    }

    function gautiPID($id)
    {
        $ataskaita = DB::table('pokalbiu_ataskaitos')->select('*')->where('id', $id)->first();
        return view('konsultantas.p_ataskaita', ['ataskaita' => $ataskaita]);
    }
}
