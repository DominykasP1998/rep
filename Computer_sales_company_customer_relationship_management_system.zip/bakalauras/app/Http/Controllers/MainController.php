<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\uzregistravimas;
use App\Models\prijungimas;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;

class MainController extends Controller
{
    function pagrindinis()
    {
        
        DB::delete('delete from prisijunge_klientai where prisijungimo_vardas = ?', [session('LoggedUser')]);

        return view('pagrindinis');
    }

    function registruotis()
    {
        return view('registracija');
    }

    function uzregistruoti(Request $request)
    {

        //Tikrinimai
        $request->validate(
            [

                'el_pastas' => 'required|email|unique:registruoti_vartotojai',
                'vardas' => 'required|min:3|max:20',
                'pavarde' => 'required|min:3|max:20',
                'prisijungimo_vardas' => 'required|min:4|max:20|unique:registruoti_vartotojai',
                'slaptazodis' => 'required|min:4|max:20',
                'miestas' => 'required',
                'amzius' => 'required|max:3',
                'tel_nr' => 'required|regex:/(370)[0-9]{8}/'

            ],

            [
                'el_pastas.required' => 'Turite nurodyti savo elektroninio pašto adresą.',
                'el_pastas.email' => 'Blogas elektroninio pašto formatas.',
                'el_pastas.unique' => 'Vartotojas tokiu el. paštu jau užregistruotas.',
                'vardas.required' => 'Privalote nurodyti savo vardą.',
                'vardas.min' => 'Vardas negali būti trumpesnis nei 3 raidės.',
                'vardas.max' => 'Vardas negali būti ilgesnis nei 20 raidžių.',
                'pavarde.required' => 'Privalote nurodyti savo pavardę.',
                'pavarde.min' => 'Pavardė negali būti trumpesnė nei 3 raidės.',
                'pavarde.max' => 'Pavardė negali būti ilgesnė nei 20 raidžių.',
                'prisijungimo_vardas.required' => 'Nenurodytas prisijungimo vardas.',
                'prisijungimo_vardas.min' => 'Prisijungimo vardas negali būti trumpesnis nei 4 simboliai.',
                'prisijungimo_vardas.max' => 'Prisijungimo vardas negali būti ilgesnis nei 20 simbolių.',
                'prisijungimo_vardas.unique' => 'Toks prisijungimo vardas jau užimtas.',
                'slaptazodis.required' => 'Neįvestas slaptažodis.',
                'slaptazodis.min' => 'Slaptažodis negali būti trumpesnis nei 4 simboliai.',
                'slaptazodis.max' => 'Slaptažodis negali būti ilgesnis nei 20 simbolių.',
                'miestas.required' => 'Nenurodytas miestas.',
                'amzius.required' => 'Nenurodytas amžius.',
                'amzius.max' => 'Amžius negali būti ilgesnis nei 3 skaičiai.',
                'tel_nr.required' => 'Nenurodytas telefono numeris.',
                'tel_nr.regex' => 'Blogas telefono numerio formatas.'
            ]
        );

        //Į duomenų bazę
        
        $uzreg = new uzregistravimas;
        $uzreg->el_pastas = $request->el_pastas;
        $uzreg->vardas = $request->vardas;
        $uzreg->pavarde = $request->pavarde;
        $uzreg->prisijungimo_vardas = $request->prisijungimo_vardas;
        $uzreg->slaptazodis = Hash::make($request->slaptazodis);
        $uzreg->miestas = $request->miestas;
        $uzreg->amzius = $request->amzius;
        $uzreg->tel_nr = $request->tel_nr;
        $uzreg->role = 'Klientas';
        $uzregistruoti = $uzreg->save();

        if ($uzregistruoti) {
            return back()->with('Pavyko', 'Registracija sėkminga! Dabar galite prisijungti.');
        } else {
            return back()->with('Klaida', 'Užsiregistruoti nepavyko.');
        }
    }

    function prijungimas(Request $request, $id = null) {

        //Tikrinimas
        $request->validate([

            'prisijungimo_vardas' => 'required',
            'slaptazodis' => 'required'

        ],
    
        [
            'prisijungimo_vardas.required' => 'Neįvestas prisijungimo vardas.',
            'slaptazodis.required' => 'Neįvestas slaptažodis.'
        ]);
         
        $info = uzregistravimas::where('prisijungimo_vardas', '=', $request->prisijungimo_vardas)->first();
        $blok_c = DB::table('uzblokuoti_vartotojai')->select('*')->where('prisijungimo_vardas', $request->prisijungimo_vardas)->count();
        $blok_truk = DB::table('uzblokuoti_vartotojai')->select('*')->where('prisijungimo_vardas', $request->prisijungimo_vardas)->first();

        if (!$info) {
            return back()->with('Klaida', 'Toks vartotojas sistemoje neegzistuoja!');
        } else if ($blok_c == 1) { 

            return back()->with('Klaida', 'Šis vartotojas užblokuotas. Baigsis: '.$blok_truk->kada_baigsis);

        } else {

            //Tikrinam slaptažodį
            if (hash::check($request->slaptazodis, $info->slaptazodis)) {

                 $request->session()->put('LoggedUser', $info->prisijungimo_vardas);

                 if (is_null($id)) {
                    $id = $info->prisijungimo_vardas;
                }

                $prij = new prijungimas;
                $prij->el_pastas = $info->el_pastas;
                $prij->prisijungimo_vardas = $request->prisijungimo_vardas;
                $prij->vardas = $info->vardas;
                $prij->pavarde = $info->pavarde;
                $prij->miestas = $info->miestas;
                $prij->amzius = $info->amzius;
                $prij->tel_nr = $info->tel_nr;
                $prij->role = $info->role;
                $prij->save();

                if ($info->role == "Klientas") {
                return redirect('/kliento_panele');
            }

                if ($info->role == "Administratorius") {
                return redirect('/admin_panele');
            }

                if ($info->role == "Vadybininkas") {
                return redirect('/vadybininko_panele');
            }

                if ($info->role == "Konsultantas") {
                return redirect('/konsultanto_panele');
            }

            } else {
               return back()->with('Klaida', 'Slaptažodis neteisingas.');
            }
        }
    }

    function Atgal() {
        return back();
    }

    function klientop() {
        $data = ['Info'=>uzregistravimas::where('prisijungimo_vardas', '=', session('LoggedUser'))->first()];
        return view('kliento_panele', $data);
    }

    function adminop() {
        $data = ['Info'=>uzregistravimas::where('prisijungimo_vardas', '=', session('LoggedUser'))->first()];
        return view('admin_panele', $data);
    }

    function vadybininkop() {
        $data = ['Info'=>uzregistravimas::where('prisijungimo_vardas', '=', session('LoggedUser'))->first()];
        return view('vadybininko_panele', $data);
    }

    function konsultantop() {
        $data = ['Info'=>uzregistravimas::where('prisijungimo_vardas', '=', session('LoggedUser'))->first()];
        return view('konsultanto_panele', $data);
    }
}
