<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Pagination\Paginator;
use App\Models\uzregistravimas;
use Illuminate\Support\Carbon;
use App\Models\blokavimas;

class adminC extends Controller
{
    function gautiRegistruotus()
    {
        $registruoti = DB::table('registruoti_vartotojai')->select('*')->paginate(10);
        return view('administratorius.registruoti_vartotojai', ['registruoti' => $registruoti]);
    }

    function gautiPV($pv)
    {
        $users = DB::select('select * from registruoti_vartotojai where prisijungimo_vardas = ?', [$pv]);
        return view('administratorius.role', ['users' => $users]);
    }

    function suteiktiRolę(Request $request, $pv)
    {
        $rolee = $request->input('role');

        $data = DB::table('registruoti_vartotojai')->select('role')->where('prisijungimo_vardas', $pv)->first();

        if ($rolee == $data->role) {

            return back()->with('Klaida', 'Vartotojas jau su tokia role!');
        } else {

            DB::update('update registruoti_vartotojai set role = ? where prisijungimo_vardas = ?', [$rolee, $pv]);

            return redirect()->route('registruoti')->with('Sėkmė', 'Rolė sėkmingai suteikta.');
        }
    }

    function ags()
    {
        return view('administratorius.ags');
    }

    function pasirinkimas(Request $request)
    {
        $pasirinkimas = $request->input('pas');

        if ($pasirinkimas == "pasir") {
            return back()->with('Klaida', 'Nepasirinkta, ką norima peržiūrėti.');
        } else if ($pasirinkimas == "Ataskaitos") {
            return redirect()->route('ataskaitos');
        }
    }

    function ataskaitos()
    {
        $pokalbiu = DB::table('pokalbiu_ataskaitos')->select('*')->paginate(10);
        $pardavimu = DB::table('pardavimu_ataskaitos')->select('*')->paginate(10);
        return view('administratorius.ataskaitos', ['pokalbiu' => $pokalbiu], ['pardavimu' => $pardavimu]);
    }

    function gautiPokalbiuID($id)
    {
        $ataskaita = DB::table('pokalbiu_ataskaitos')->select('*')->where('id', $id)->first();
        return view('administratorius.pokalbiu_ataskaita', ['ataskaita' => $ataskaita]);
    }

    function gautiPardavimuID($id)
    {
        $ataskaita = DB::table('pardavimu_ataskaitos')->select('*')->where('Id', $id)->first();
        return view('administratorius.pardavimu_ataskaita', ['ataskaita' => $ataskaita]);
    }

    function forumas()
    {
        $temos = DB::table('forumo_temos')->select('*')->paginate(10);
        return view('administratorius.forumas', ['temos' => $temos]);
    }

    function atsiliepimai()
    {
        $atsiliepimai = DB::table('atsiliepimai')->select('*')->paginate(10);
        return view('administratorius.atsiliepimai', ['atsiliepimai' => $atsiliepimai]);
    }

    function naikinti_atsiliepima($id)
    {
        DB::delete('Delete from atsiliepimai where id = ?', [$id]);
        return back()->with('Sėkmė', 'Atsiliepimas sėkmingai panaikintas.');
    }

    function naikinti_tema($id)
    {
        DB::delete('Delete from forumo_temos where id = ?', [$id]);
        return back()->with('Sėkmė', 'Forumo tema sėkmingai panaikinta.');
    }

    function naikinti_zinute($id)
    {
        DB::delete('Delete from forumo_zinutes where id = ?', [$id]);
        return back()->with('Sėkmė', 'Žinutė sėkmingai panaikinta.');
    }

    function zinutes($id)
    {
        $zinutes = DB::table('forumo_zinutes')->select('*')->where('fk_FORUMO_TEMOSid', $id)->paginate(10);
        $pavadinimas = DB::table('forumo_temos')->select('*')->where('id', $id)->first();
        $zin_count = DB::table('forumo_zinutes')->select('*')->where('fk_FORUMO_TEMOSid', $id)->count();
        view('administratorius.vartotojo_blokavimas', ['pavadinimas' => $pavadinimas]);
        return view('administratorius.forumo_zinutes', ['zinutes' => $zinutes], ['pavadinimas' => $pavadinimas], ['zin_count' => $zin_count]);
    }


    function blokuoti_vartotoja($pv)
    {
        $pv = DB::table('registruoti_vartotojai')->select('*')->where('prisijungimo_vardas', $pv)->first();
        return view('administratorius.vartotojo_blokavimas', ['pv' => $pv]);
    }

    function blokuoti_vartotoja_commit(Request $request, $pv)
    {


        $skaicius = DB::table('uzblokuoti_vartotojai')->select('*')->where('prisijungimo_vardas', $pv)->count();

        if ($skaicius == 1) {

            return back()->with('Klaida', 'Šis vartotojas jau užblokuotas!');
            DB::table('uzblokuoti_vartotojai')->select('*')->where(Carbon::parse('kada_baigsis'), '<', Carbon::now())->delete();
        } else if ($request->prie == "Priežastis") {

            return back()->with('Klaida', 'Nenurodėte priežasties!');
        } else if ($request->truk == "Trukmė") {
            return back()->with('Klaida', 'Nenurodėte trukmės!');
        } else {

            $bausme = Carbon::now()->addHours($request->truk + 3);

            $blok = new blokavimas;
            $blok->prisijungimo_vardas = $pv;
            $blok->priezastis = $request->prie;
            $blok->trukme_val = $request->truk;
            $blok->kada_baigsis = $bausme;
            $patikrinti = $blok->save();

            if ($patikrinti) {
                return redirect()->route('forumas')->with('Sėkmė', 'Vartotojas užblokuotas sėkmingai.');
            } else {
                return back()->with('Klaida', 'Vartotojo užblokuoti nepavyko.');
            }
        }
    }
}
