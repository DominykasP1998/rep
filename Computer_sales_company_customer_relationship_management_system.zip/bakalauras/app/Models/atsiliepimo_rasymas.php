<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class atsiliepimo_rasymas extends Model
{
    use HasFactory;

    public $timestamps = false;
    
    protected $table = 'atsiliepimai';

    protected $fillable = [
        'tipas', 'atsiliepimas', 'prisijungimo_vardas', 'fk_REGISTRUOTI_VARTOTOJAIid'
    ];
}
