<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class zinutes_rasymas extends Model
{
    use HasFactory;

    public $timestamps = false;
    
    protected $table = 'forumo_zinutes';

    protected $fillable = [
        'prisijungimo_vardas', 'zinute', 'fk_FORUMO_TEMOSid', 'fk_REGISTRUOTI_VARTOTOJAIid'
    ];
}
