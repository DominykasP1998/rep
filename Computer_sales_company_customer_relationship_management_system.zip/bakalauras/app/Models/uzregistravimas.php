<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class uzregistravimas extends Model
{
    use HasFactory;
    
    public $timestamps = false;
    
    protected $table = 'registruoti_vartotojai';

    protected $fillable = [
        'el_pastas', 'vardas', 'pavarde', 'prisijungimo_vardas', 'slaptazodis', 'miestas', 'amzius', 'tel_nr', 'role'
    ];

    protected $hidden = [
        'slaptazodis'
    ];
}
