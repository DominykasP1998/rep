<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class pokalbiui extends Model
{
    use HasFactory;

    public $timestamps = false;
    
    protected $table = 'uzregistruoti_pokalbiai';

    protected $fillable = [
        'kliento_vardas', 'kliento_pavarde', 'konsultanto_vardas', 'konsultanto_pavarde', 'data', 'laikas', 'fk_REGISTRUOTI_VARTOTOJAIid'
    ];

}
