<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class blokavimas extends Model
{
    use HasFactory;

    public $timestamps = false;
    
    protected $table = 'uzblokuoti_vartotojai';

    protected $fillable = [
        'prisijungimo_vardas', 'priezastis', 'trukme_val', 'kada_baigsis'
    ];
}
