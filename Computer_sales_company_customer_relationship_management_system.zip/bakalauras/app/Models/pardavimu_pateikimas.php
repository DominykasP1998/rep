<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class pardavimu_pateikimas extends Model
{
    use HasFactory;

    public $timestamps = false;
    
    protected $table = 'pardavimu_ataskaitos';

    protected $fillable = [
        'autorius', 'kiek_pasiule', 'kiek_uzsisake', 'pardavimo_suma', 'fk_REGISTRUOTI_VARTOTOJAIid'
    ];
}
