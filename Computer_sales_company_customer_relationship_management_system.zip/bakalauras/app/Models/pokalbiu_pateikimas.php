<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class pokalbiu_pateikimas extends Model
{
    use HasFactory;

    public $timestamps = false;
    
    protected $table = 'pokalbiu_ataskaitos';

    protected $fillable = [
        'autorius', 'kliento_vardas', 'kliento_pavarde', 'prisijungimo_vardas', 'amzius', 'miestas', 'tel_nr', 'trukme', 'kliento_busena', 'fk_REGISTRUOTI_VARTOTOJAIid'
    ];

}
