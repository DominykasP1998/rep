<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Kliento panelė</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
    <div class="container mx-auto" style="margin-top:50px; border-style: solid; border-width: 3px 3px 1px 3px; background-color: #B08348;">
        <h4 class="text-center">Kliento valdymo skydas</h4>
    </div>
    <div class="container" style="border-style: solid; background-color: #DEB887;">
        <nav class="navbar navbar-light" style="background-color: #e3f2fd; margin-left:-15px; border-style: solid; border-width: 0px 0px 3px 0px;">
            <ul class="nav justify-content-left">
                <li class="nav-item active">
                    <a class="nav-link disabled" href="/kliento_panele" style="border-style:solid;">Valdymo skydas <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/prekiu_sarasas" style="border-style:solid; margin-left:5px;">Prekių sąrašas</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/noru_sarasas" style="border-style:solid; margin-left:5px;">Norų sąrašas</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/registracija_pokalbiui" style="border-style:solid; margin-left:5px;">Registracija pokalbiui</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/patarimai" style="border-style:solid; margin-left:5px;">Patarimai įvykus gedimui</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/atsiliepimai_k" style="border-style:solid; margin-left:5px;">Atsiliepimai</a>
                </li>
            </ul>
            <ul class="nav justify-content-left" style="margin-top:20px; margin-left:-5px;">
                <li class="nav-item">
                    <a class="nav-link" href="/serveriai" style="border-style:solid; margin-left:5px;">Serverių užsakymas</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/forumas_k" style="border-style:solid; margin-left:5px;">Forumas</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('pagrindinis')); ?>" style="color: red; border-style:solid; margin-left:5px;">Atsijungti</a>
                </li>
            </ul>
        </nav>
        <h5 class="text-center" style="margin-top:50px; margin-bottom:30px;">Sveiki, <?php echo e($Info['prisijungimo_vardas']); ?>!</h5>
    </div>
    <div class="container mx-auto" style="border-style: solid; border-width: 0px 3px 3px 3px; background-color: #B08348;">
        <h6 class="text-center">©kpikvs.lt visos teisės saugomos</h6>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\bakalauras\resources\views/kliento_panele.blade.php ENDPATH**/ ?>