<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>'PA<?php echo e($ataskaita->id); ?>' ataskaita</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
    <div class="container" style="margin-top:50px; border-style: solid; border-width: 3px 3px 1px 3px; background-color: #B08348;">
        <h4 class="text-center">'PA<?php echo e($ataskaita->id); ?>' ataskaita </h4>
    </div>
    <div class="container mx-auto" style="border-style: solid; background-color: #DEB887;">
    <nav class="navbar navbar-light" style="background-color: #e3f2fd; margin-left:-15px; border-style: solid; border-width: 0px 0px 3px 0px;">
                <ul class="nav justify-content-left">
                    <li class="nav-item active">
                        <a class="nav-link" href="/admin_panele" style="border-style:solid;">Valdymo skydas <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/ags" style="border-style:solid; margin-left:5px;">Ataskaitos, grafikai, statistika</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/ataskaitos" style="border-style:solid; margin-left:5px;">Ataskaitos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link disabled" href="" style="border-style:solid; margin-left:5px;">Pokalbių ataskaita 'PA<?php echo e($ataskaita->id); ?>' <?php echo e($ataskaita->pateikimo_data); ?></a>
                    </li>
                </ul>
    </nav>
        <h5 class="text-center" style="margin-top:50px; margin-bottom:30px;">Pokalbių ataskaita 'PA<?php echo e($ataskaita->id); ?>' <?php echo e($ataskaita->pateikimo_data); ?></h5>
        <div class="text-center" style="margin-bottom:30px;">
            <h6>Autorius: <?php echo e($ataskaita->autorius); ?></h6>
            <h6>Kliento vardas: <?php echo e($ataskaita->kliento_vardas); ?></h6>
            <h6>Kliento pavardė: <?php echo e($ataskaita->kliento_pavarde); ?></h6>
            <h6>Kliento prisijungimo vardas: <?php echo e($ataskaita->prisijungimo_vardas); ?></h6>
            <h6>Amžius: <?php echo e($ataskaita->amzius); ?></h6>
            <h6>Miestas: <?php echo e($ataskaita->miestas); ?></h6>
            <h6>Telefono numeris: <?php echo e($ataskaita->tel_nr); ?></h6>
            <h6>Pokalbio trukmė: <?php echo e($ataskaita->trukme); ?> min.</h6>
            <h6>Spėjama kliento būsena: <?php echo e($ataskaita->kliento_busena); ?></h6>
        </div>
    </div>
    <div class="container mx-auto" style="border-style: solid; border-width: 0px 3px 3px 3px; background-color: #B08348;">
        <h6 class="text-center">©kpikvs.lt visos teisės saugomos</h6>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\bakalauras\resources\views/administratorius/pokalbiu_ataskaita.blade.php ENDPATH**/ ?>