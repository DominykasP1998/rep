<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Registracija pokalbiui</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css" />
    <script>
        $(document).ready(function() {
            var date_input = $('input[name="date"]'); 
            var container = $('.bootstrap-iso form').length > 0 ? $('.bootstrap-iso form').parent() : "body";
            date_input.datepicker({
                format: 'yyyy-mm-dd',
                container: container,
                todayHighlight: true,
                autoclose: true,
            })
        })
    </script>
</head>

<body>
    <div class="container mx-auto" style="margin-top:50px; border-style: solid; border-width: 3px 3px 1px 3px; background-color: #B08348;">
        <h4 class="text-center">Registracija pokalbiui</h4>
    </div>
    <div class="container" style="border-style: solid; background-color: #DEB887;">
    <nav class="navbar navbar-light" style="background-color: #e3f2fd; margin-left:-15px; border-style: solid; border-width: 0px 0px 3px 0px;">
            <ul class="nav justify-content-left">
                <li class="nav-item active">
                    <a class="nav-link" href="/kliento_panele" style="border-style:solid;">Valdymo skydas <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link disabled" href="" style="border-style:solid; margin-left:5px;">Registracija pokalbiui su konsultantu</a>
                </li>
            </ul>
        </nav>
        <div class="row" style="margin-top:45px ; margin-bottom:45px ;">
            <div class="col-md-4 mx-auto">
                <div class="text-center" style="margin-bottom:30px;">
                    <h5>Registracija pokalbiui su konsultantu</h5>
                </div>
                <form action="<?php echo e(route('uzregistruoti_p')); ?>" method="post">

                    <?php if(Session::get('Sekme')): ?>
                    <div class='alert alert-success'>
                        <?php echo e(Session::get('Sekme')); ?>

                    </div>
                    <?php endif; ?>

                    <?php if(Session::get('Klaida')): ?>
                    <div class='alert alert-danger'>
                        <?php echo e(Session::get('Klaida')); ?>

                    </div>
                    <?php endif; ?>

                    <?php echo csrf_field(); ?>
                    <input class="form-control form-control-sm" style="margin-bottom:30px; margin-left:35px; width:80%;" id="date" name="date" placeholder="Pasirinkite datą" type="text" value="<?php echo e(old('date')); ?>" />
                    <div class="text-center" style="margin-bottom:5px;">
                        <h6>Pasirinkite laiką: </h6>
                    </div>
                    <div class="row">
                        <select class="form-control form-control-sm" name="valandos" style="margin-left:50px; width:70%; margin-bottom:30px; width:30%;" value="<?php echo e(old('valandos')); ?>">
                            <option selected value="v">Valandos</option>
                            <?php for($i = 8; $i <= 17; $i++): ?> <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                <?php endfor; ?>
                        </select>
                        <select class="form-control form-control-sm" name="minutes" style="margin-left:50px; width:70%; margin-bottom:30px; width:30%;" value="<?php echo e(old('minutes')); ?>">
                            <option selected value="m">Minutės</option>
                            <option value="00">00</option>
                            <option value="10">10</option>
                            <option value="20">20</option>
                            <option value="30">30</option>
                            <option value="40">40</option>
                            <option value="50">50</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-block btn-primary">Registruotis</button>
                    <br>
                </form>
            </div>
        </div>
    </div>
    <div class="container mx-auto" style="border-style: solid; border-width: 0px 3px 3px 3px; background-color: #B08348;">
        <h6 class="text-center">©kpikvs.lt visos teisės saugomos</h6>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\bakalauras\resources\views/klientas/pokalbiui.blade.php ENDPATH**/ ?>