<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Registracija</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
<div class="container mx-auto" style="margin-top:50px; border-style: solid; border-width: 3px 3px 1px 3px; background-color: #B08348;">
        <h4 class="text-center">Registracijos puslapis</h4>
    </div>
    <div class="container" style="border-style: solid; border-width: 2px 3px 3px 3px; background-color: #DEB887;">
        <div class="row" style="margin-top:45px ; margin-bottom:45px ;">
            <div class="col-md-4 mx-auto">
                <div class="text-center" style="margin-bottom:30px;">
                    <h5>Registracija</h5>
                </div>
                <form action="<?php echo e(route('uzregistruoti')); ?>" method="post">

                    <?php if(Session::get('Pavyko')): ?>
                    <div class='alert alert-success'>
                        <?php echo e(Session::get('Pavyko')); ?>

                    </div>
                    <?php endif; ?>

                    <?php if(Session::get('Klaida')): ?>
                    <div class='alert alert-danger'>
                        <?php echo e(Session::get('Klaida')); ?>

                    </div>
                    <?php endif; ?>

                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <input type="text" class="form-control" name="el_pastas" placeholder="El. Paštas" value="<?php echo e(old('el_pastas')); ?>">
                        <span class="text-danger"><?php $__errorArgs = ['el_pastas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" name="vardas" placeholder="Vardas" value="<?php echo e(old('vardas')); ?>">
                        <span class="text-danger"><?php $__errorArgs = ['vardas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" name="pavarde" placeholder="Pavardė" value="<?php echo e(old('pavarde')); ?>">
                        <span class="text-danger"><?php $__errorArgs = ['pavarde'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" name="prisijungimo_vardas" placeholder="Prisijungimo vardas (ilgis: 4-20)" value="<?php echo e(old('prisijungimo_vardas')); ?>">
                        <span class="text-danger"><?php $__errorArgs = ['prisijungimo_vardas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-control" name="slaptazodis" placeholder="Slaptažodis (ilgis: 4-20)">
                        <span class="text-danger"><?php $__errorArgs = ['slaptazodis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" name="miestas" placeholder="Miestas" value="<?php echo e(old('miestas')); ?>">
                        <span class="text-danger"><?php $__errorArgs = ['miestas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                    </div>
                    <div class="form-group">
                        <input type="number" class="form-control" name="amzius" placeholder="Amžius" value="<?php echo e(old('amzius')); ?>">
                        <span class="text-danger"><?php $__errorArgs = ['amzius'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                    </div>
                    <div class="form-group">
                        <input type="tel" class="form-control" name="tel_nr" placeholder="Telefono numeris (370...)" value="<?php echo e(old('tel_nr')); ?>">
                        <span class="text-danger"><?php $__errorArgs = ['tel_nr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                    </div>
                    <button type="submit" class="btn btn-block btn-primary">Registruotis</button>
                    <br>
                    <a class="btn btn-dark" style="margin-left:145px;" href="<?php echo e(route('pagrindinis')); ?>" role="button">Atgal</a>
                </form>
            </div>
        </div>
    </div>
    <div class="container mx-auto" style="border-style: solid; border-width: 0px 3px 3px 3px; background-color: #B08348;">
        <h6 class="text-center">©kpikvs.lt visos teisės saugomos</h6>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\bakalauras\resources\views/registracija.blade.php ENDPATH**/ ?>