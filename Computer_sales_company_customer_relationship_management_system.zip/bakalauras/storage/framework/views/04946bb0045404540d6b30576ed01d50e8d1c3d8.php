<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Patarimai</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
    <div class="container" style="margin-top:50px; border-style: solid; width: 50%; border-width: 3px 3px 1px 3px; background-color: #B08348;">
        <h4 class="text-center">Patarimai</h4>
    </div>
    <div class="container mx-auto" style="border-style: solid; background-color: #DEB887; width: 50%;">
    <nav class="navbar navbar-light" style="background-color: #e3f2fd; margin-left:-15px; border-style: solid; border-width: 0px 0px 3px 0px;">
            <ul class="nav justify-content-left">
                <li class="nav-item active">
                    <a class="nav-link" href="/kliento_panele" style="border-style:solid;">Valdymo skydas <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/patarimai" style="border-style:solid; margin-left:5px;">Patarimai įvykus gedimui</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link disabled" href="" style="border-style:solid; margin-left:5px;">Patarimų sąrašas</a>
                </li>
            </ul>
        </nav>
        <h6 class="text-center" style="margin-top:50px; margin-bottom:50px; border-width: 1px 3px 3px 3px;">Patarimų sąrašas</h6>

        <?php if(Session::get('Sėkmė')): ?>
        <div class='alert alert-success text-center' style="margin-left:auto; margin-right:auto; width: 80%;">
            <?php echo e(Session::get('Sėkmė')); ?>

        </div>
        <?php endif; ?>

        <?php if(Session::get('Klaida')): ?>
        <div class='alert alert-danger text-center' style="margin-left:auto; margin-right:auto; width: 80%;">
            <?php echo e(Session::get('Klaida')); ?>

        </div>
        <?php endif; ?>

        <div class="container" style="border-style: solid; background-color: #f7d5a8; width: 80%; margin-bottom: 30px;">
            <?php $__currentLoopData = $patarimai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            • <?php echo e($p->patarimas); ?> <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div style="margin-left:255px; margin-bottom: 20px;">
            <?php echo e($patarimai->render()); ?>

        </div>
    </div>
    <div class="container mx-auto" style="margin-bottom: 50px; border-style: solid; width: 50%; border-width: 0px 3px 3px 3px; background-color: #B08348;">
        <h6 class="text-center">©kpikvs.lt visos teisės saugomos</h6>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\bakalauras\resources\views/klientas/patarimu_s.blade.php ENDPATH**/ ?>