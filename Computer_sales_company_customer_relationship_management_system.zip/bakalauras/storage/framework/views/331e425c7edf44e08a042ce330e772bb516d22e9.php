<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Temos '<?php echo e($pavadinimas->pavadinimas); ?>' žinutės</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
    <div class="container" style="margin-top:50px; border-style: solid; width: 60%; border-width: 3px 3px 1px 3px; background-color: #B08348;">
        <h4 class="text-center">Temos '<?php echo e($pavadinimas->pavadinimas); ?>' žinutės</h4>
    </div>
    <div class="container mx-auto" style="border-style: solid; background-color: #DEB887; width: 60%;">
    <nav class="navbar navbar-light" style="background-color: #e3f2fd; margin-left:-15px; border-style: solid; border-width: 0px 0px 3px 0px;">
                <ul class="nav justify-content-left">
                    <li class="nav-item active">
                        <a class="nav-link" href="/kliento_panele" style="border-style:solid;">Valdymo skydas <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/forumas_k" style="border-style:solid; margin-left:5px;">Forumas</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link disabled" href="" style="border-style:solid; margin-left:5px;">Temos '<?php echo e($pavadinimas->pavadinimas); ?>' žinutės</a>
                    </li>
                </ul>
    </nav>
        <h6 class="text-center" style="margin-top:50px; margin-bottom:50px; border-width: 1px 3px 3px 3px;">Temos '<?php echo e($pavadinimas->pavadinimas); ?>' žinutės</h6>

        <?php if(Session::get('Sėkmė')): ?>
        <div class='alert alert-success text-center' style="margin-left:auto; margin-right:auto; width: 80%;">
            <?php echo e(Session::get('Sėkmė')); ?>

        </div>
        <?php endif; ?>

        <?php if(Session::get('Klaida')): ?>
        <div class='alert alert-danger text-center' style="margin-left:auto; margin-right:auto; width: 80%;">
            <?php echo e(Session::get('Klaida')); ?>

        </div>
        <?php endif; ?>

        <div class="container mx-auto" style="border-style: solid; background-color: #f7d5a8; width: 80%; margin-bottom: 30px;">
            <?php $__currentLoopData = $zinutes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $z): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="container mx-auto" style="border-style: solid; background-color: #ffffff; margin-top: 20px; border-width: 2px 2px 1px 2px; width: 90%;">
                <?php echo e($z->prisijungimo_vardas); ?> rašo: <br>
            </div>
            <div class="container mx-auto text-center" style="border-style: solid; background-color: #ffffff; margin-bottom: 10px; border-width: 1px 2px 2px 2px; width: 90%;">
                <?php echo e($z->zinute); ?> <br>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div style="margin-left:255px; margin-bottom: 20px;">
            <?php echo e($zinutes->links()); ?>

        </div>
        <form action="/rasyti_zinute/<?php echo e($pavadinimas->id); ?>" method="post" class="col-md-4 mx-auto">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <textarea class="form-control" style="margin-bottom: 35px;" name="zin" rows="3" placeholder="Jūsų žinutė" value="<?php echo e(old('zin')); ?>"></textarea>
                <span class="text-danger"><?php $__errorArgs = ['zin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
            </div>
            <button type="submit" class="btn btn-block btn-primary mx-auto" style="width: 50%;">Rašyti</button>
            <br>
        </form>
    </div>
    <div class="container mx-auto" style="margin-bottom: 50px; border-style: solid; width: 60%; border-width: 0px 3px 3px 3px; background-color: #B08348;">
        <h6 class="text-center">©kpikvs.lt visos teisės saugomos</h6>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\bakalauras\resources\views/klientas/forumo_zinutes.blade.php ENDPATH**/ ?>