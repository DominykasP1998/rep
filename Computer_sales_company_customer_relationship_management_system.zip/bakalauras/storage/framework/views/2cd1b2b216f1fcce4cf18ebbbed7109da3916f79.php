<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Norų sąrašas</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
    <div class="container" style="margin-top:50px; border-style: solid; width: 60%; border-width: 3px 3px 1px 3px; background-color: #B08348;">
        <h4 class="text-center">Norų sąrašas</h4>
    </div>
    <div class="container mx-auto" style="border-style: solid; background-color: #DEB887; width: 60%;">
        <nav class="navbar navbar-light" style="background-color: #e3f2fd; margin-left:-15px; border-style: solid; border-width: 0px 0px 3px 0px;">
            <ul class="nav justify-content-left">
                <li class="nav-item active">
                    <a class="nav-link" href="/kliento_panele" style="border-style:solid;">Valdymo skydas <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link disabled" href="/noru_sarasas" style="border-style:solid; margin-left:5px;">Norų sąrašas</a>
                </li>
            </ul>
        </nav>
        <h6 class="text-center" style="margin-top:50px; margin-bottom:50px; border-width: 1px 3px 3px 3px;">Norų sąrašas</h6>

        <?php if(Session::get('Sėkmė')): ?>
        <div class='alert alert-success text-center' style="margin-left:auto; margin-right:auto; width: 80%;">
            <?php echo e(Session::get('Sėkmė')); ?>

        </div>
        <?php endif; ?>

        <?php if(Session::get('Klaida')): ?>
        <div class='alert alert-danger text-center' style="margin-left:auto; margin-right:auto; width: 80%;">
            <?php echo e(Session::get('Klaida')); ?>

        </div>
        <?php endif; ?>
        <div class="input-group" style="margin-left:250px; margin-bottom:20px;">
            <div class="form-outline">
                <input type="search" id="form1" class="form-control" placeholder="Ieškoti prekės" />
            </div>
            <button type="button" class="btn btn-primary">Ieškoti</button>
        </div>
        <div class="container" style="border-style: solid; background-color: #f7d5a8; width: 80%; margin-bottom: 80px;">
            <div class="row">
                <?php $__currentLoopData = $prekes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="container-fluid" style="border-style: solid; background-color: #ffffff; margin-top: 20px; border-width: 2px 2px 2px 2px; width: 30%; margin-left: 60px; margin-bottom:20px;">
                    <div class="text-center" style="margin-bottom: 10px;">
                        <?php echo e($p->pavadinimas); ?> <br>
                    </div>
                    <div style="border-style: solid; border-width: 1px 1px 1px 1px; text-align:center; margin-bottom:10px;">
                        <?php $blob = $p->nuotr;
                        echo '<img src="data:image/jpeg;base64,' . base64_encode($blob) . '"/>'; ?> <br>
                    </div>
                    <p><?php echo e($p->aprasymas); ?></p>
                    <?php if($p->ar_nuolaida == "Ne"): ?>
                    <span class="text-center align-bottom">
                        <h6>Kaina: <?php echo e($p->kaina); ?> €</h6>
                        <a class="btn btn-info" style="margin-bottom:20px;" href="f_uzsakyma_pn/<?php echo e($p->id); ?>" role="button">Formuoti užsakymą</a>
                        <a class="btn btn-info" style="margin-bottom:20px; margin-left:33px;" href="naikinti_nora/<?php echo e($p->id); ?>" role="button">Naikinti</a>
                    </span>
                    <?php else: ?>
                    <?php

                    $sena_kaina = $p->kaina;
                    $kof = $p->nuo_dydis_proc / 100;
                    $nauja_kaina = round(($sena_kaina - ($sena_kaina * $kof)), 2);

                    ?>
                    <span class="text-center align-bottom">
                        <h6 style="color: red;">Akcija!</h6>
                        <h6 style="color: red;">Kaina: <?php echo e($nauja_kaina); ?>€ (Sena kaina: <?php echo e($sena_kaina); ?> €)</h6>
                        <a class="btn btn-info" style="margin-bottom:20px;" href="f_uzsakyma_pn/<?php echo e($p->id); ?>" role="button">Formuoti užsakymą</a>
                        <a class="btn btn-info" style="margin-bottom:20px; margin-left:33px;" href="naikinti_nora/<?php echo e($p->id); ?>" role="button">Naikinti</a>
                    </span>
                    <?php endif; ?>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div style="margin-left:230px;">
                <?php echo e($prekes->render()); ?>

            </div>
        </div>
    </div>
    <div class="container mx-auto" style="margin-bottom: 50px; border-style: solid; width: 60%; border-width: 0px 3px 3px 3px; background-color: #B08348;">
        <h6 class="text-center">©kpikvs.lt visos teisės saugomos</h6>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\bakalauras\resources\views/klientas/noru_sarasas.blade.php ENDPATH**/ ?>