<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pokalbių ataskaitos kūrimas</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
    <div class="container mx-auto" style="margin-top:50px; border-style: solid; border-width: 3px 3px 1px 3px; background-color: #B08348;">
        <h4 class="text-center">Pokalbių ataskaitos kūrimas</h4>
    </div>
    <div class="container" style="border-style: solid; border-width: 2px 3px 3px 3px; background-color: #DEB887;">
    <nav class="navbar navbar-light" style="background-color: #e3f2fd; margin-left:-15px; border-style: solid; border-width: 0px 0px 3px 0px;">
                <ul class="nav justify-content-left">
                    <li class="nav-item active">
                        <a class="nav-link" href="/konsultanto_panele" style="border-style:solid;">Valdymo skydas <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/pokalbiu_ataskaitos" style="border-style:solid; margin-left:5px;">Pokalbių ataskaitos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link disabled" href="" style="border-style:solid; margin-left:5px;">Naujos ataskaitos kūrimas</a>
                    </li>
                </ul>
    </nav>
        <div class="row" style="margin-top:45px; margin-bottom:45px ;">
            <div class="col-md-4 mx-auto">
                <div class="text-center" style="margin-bottom:30px;">
                    <h5>Naujos ataskaitos kūrimas</h5>
                </div>
                <form action="<?php echo e(route('pateikti')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <input type="text" class="form-control" name="kv" placeholder="Kliento vardas" value="<?php echo e(old('kv')); ?>">
                        <span class="text-danger"><?php $__errorArgs = ['kv'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" name="kp" placeholder="Kliento pavardė" value="<?php echo e(old('kp')); ?>">
                        <span class="text-danger"><?php $__errorArgs = ['kp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" name="kpv" placeholder="Kliento prisijungimo vardas" value="<?php echo e(old('kpv')); ?>">
                        <span class="text-danger"><?php $__errorArgs = ['kpv'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                    </div>
                    <div class="form-group">
                        <input type="number" class="form-control" name="amzius" placeholder="Amžius" value="<?php echo e(old('amzius')); ?>">
                        <span class="text-danger"><?php $__errorArgs = ['amzius'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                    </div>
                    <div class="form-group">
                        <input type="tel" class="form-control" name="tel_nr" placeholder="Telefono numeris (370...)" value="<?php echo e(old('tel_nr')); ?>">
                        <span class="text-danger"><?php $__errorArgs = ['tel_nr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" name="miestas" placeholder="Miestas" value="<?php echo e(old('miestas')); ?>">
                        <span class="text-danger"><?php $__errorArgs = ['miestas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                    </div>
                    <div class="form-group">
                        <input type="number" class="form-control" name="trukme" placeholder="Pokalbio trukmė (min.)" value="<?php echo e(old('trukme')); ?>">
                        <span class="text-danger"><?php $__errorArgs = ['trukme'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                    </div>
                    <div class="form-group">
                        <input type="tel" class="form-control" name="busena" placeholder="Spėjama kliento būsena" value="<?php echo e(old('busena')); ?>">
                        <span class="text-danger"><?php $__errorArgs = ['busena'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                    </div>
                    <button type="submit" class="btn btn-block btn-primary">Pateikti</button>
                    <br>
                </form>
            </div>
        </div>
    </div>
    <div class="container mx-auto" style="border-style: solid; border-width: 0px 3px 3px 3px; background-color: #B08348;">
        <h6 class="text-center">©kpikvs.lt visos teisės saugomos</h6>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\bakalauras\resources\views/konsultantas/nauja_ataskaita.blade.php ENDPATH**/ ?>