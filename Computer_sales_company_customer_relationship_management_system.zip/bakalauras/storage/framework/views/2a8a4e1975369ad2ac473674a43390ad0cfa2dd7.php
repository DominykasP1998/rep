<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Forumas</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
    <div class="container" style="margin-top:50px; border-style: solid; border-width: 3px 3px 1px 3px; background-color: #B08348;">
        <h4 class="text-center">Forumas</h4>
    </div>
    <div class="container mx-auto" style="border-style: solid; background-color: #DEB887;">
    <nav class="navbar navbar-light" style="background-color: #e3f2fd; margin-left:-15px; border-style: solid; border-width: 0px 0px 3px 0px;">
                <ul class="nav justify-content-left">
                    <li class="nav-item active">
                        <a class="nav-link" href="/admin_panele" style="border-style:solid;">Valdymo skydas <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link disabled" href="/forumas" style="border-style:solid; margin-left:5px;">Forumas</a>
                    </li>
                </ul>
    </nav>
        <h6 class="text-center" style="margin-top:50px; margin-bottom:50px;">Forumas</h6>

        <?php if(Session::get('Sėkmė')): ?>
        <div class='alert alert-success text-center' style="width:50%; margin-left:auto; margin-right:auto;">
            <?php echo e(Session::get('Sėkmė')); ?>

        </div>
        <?php endif; ?>

        <?php if(Session::get('Klaida')): ?>
        <div class='alert alert-danger text-center' style="width:50%; margin-left:auto; margin-right:auto;">
            <?php echo e(Session::get('Klaida')); ?>

        </div>
        <?php endif; ?>

        <table class="table table-light" style="margin-bottom:30px; width:50%; margin-left:auto; margin-right:auto;">
            <thead class="thead-dark">
                <tr>
                    <th scope="col">Temos pavadinimas</th>
                    <th scope="col">Veiksmas</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $temos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><a class="text-dark" href="temos/<?php echo e($t->id); ?>"><?php echo e($t->pavadinimas); ?></a></td>
                    <td><a class="btn btn-info" href="naikinti_tema/<?php echo e($t->id); ?>" role="button">Naikinti</a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div style="margin-left:493px;">
            <?php echo e($temos->links()); ?>

        </div>
    </div>
    <div class="container mx-auto" style="border-style: solid; border-width: 0px 3px 3px 3px; background-color: #B08348;">
        <h6 class="text-center">©kpikvs.lt visos teisės saugomos</h6>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\bakalauras\resources\views/administratorius/forumas.blade.php ENDPATH**/ ?>