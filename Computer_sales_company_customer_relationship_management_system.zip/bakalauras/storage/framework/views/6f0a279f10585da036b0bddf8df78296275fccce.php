<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>'PA<?php echo e($ataskaita->Id); ?>' ataskaita</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
    <div class="container" style="margin-top:50px; border-style: solid; border-width: 3px 3px 1px 3px; background-color: #B08348;">
        <h4 class="text-center">'PA<?php echo e($ataskaita->Id); ?>' ataskaita </h4>
    </div>
    <div class="container mx-auto" style="border-style: solid; background-color: #DEB887;">
    <nav class="navbar navbar-light" style="background-color: #e3f2fd; margin-left:-15px; border-style: solid; border-width: 0px 0px 3px 0px;">
                <ul class="nav justify-content-left">
                    <li class="nav-item active">
                        <a class="nav-link" href="/vadybininko_panele" style="border-style:solid;">Valdymo skydas <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/pardavimu_ataskaitos" style="border-style:solid; margin-left:5px;">Pardavimo ataskaitos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link disabled" href="" style="border-style:solid; margin-left:5px;">Pardavimų ataskaita 'PA<?php echo e($ataskaita->Id); ?>' <?php echo e($ataskaita->pateikimo_data); ?></a>
                    </li>
                </ul>
    </nav>
        <h5 class="text-center" style="margin-top:50px; margin-bottom:30px;">Pardavimų ataskaita 'PA<?php echo e($ataskaita->Id); ?>' <?php echo e($ataskaita->pateikimo_data); ?></h5>
        <div class="text-center">
            <h6>Autorius: <?php echo e($ataskaita->autorius); ?></h6>
            <h6>Kiek klientų pasiūlė prekę: <?php echo e($ataskaita->kiek_pasiule); ?></h6>
            <h6>Kiek klientų užsisakė prekę: <?php echo e($ataskaita->kiek_uzsisake); ?></h6>
            <h6>Parduota prekių už: <?php echo e($ataskaita->pardavimo_suma); ?> €</h6>
        </div>
            <a class="btn btn-dark" style="margin-bottom:30px; margin-left:518px; margin-top:20px;" href="<?php echo e(route('pardavimu')); ?>" role="button">Atgal</a>
    </div>
    <div class="container mx-auto" style="border-style: solid; border-width: 0px 3px 3px 3px; background-color: #B08348;">
        <h6 class="text-center">©kpikvs.lt visos teisės saugomos</h6>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\bakalauras\resources\views/vadybininkas/pard_ataskaita.blade.php ENDPATH**/ ?>