<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pagrindinis puslapis</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
    <div class="container mx-auto" style="margin-top:50px; border-style: solid; border-width: 3px 3px 1px 3px; background-color: #B08348;">
        <h4 class="text-center">Pagrindinis puslapis</h4>
    </div>
    <div class="container" style="border-style: solid; border-width: 3px 3px 1px 3px; background-color: #DEB887;">
        <a class="btn btn-block btn-secondary col-md-2" style="margin-left:850px; margin-top:5px; margin-bottom:5px;" href="{{ route('registracija') }}" role="button">Registracija</a>
    </div>
    <div class="container" style="border-style: solid; background-color: #DEB887;">
        <div class="row" style="margin-top:45px ; margin-bottom:45px ;">
            <div class="col-md-4 mx-auto">
                <div class="text-center">
                    <h5>Prisijungimas</h5>
                </div>
                <form action="{{ route('prijungimas') }}" method="post">

                    @if(Session::get('Klaida'))
                    <div class='alert alert-danger'>
                        {{ Session::get('Klaida') }}
                    </div>
                    @endif

                    @csrf
                    <div class="form-group">
                        <input type="text" class="form-control" name="prisijungimo_vardas" placeholder="Vartotojo vardas" value="{{ old('prisijungimo_vardas') }}">
                        <span class="text-danger">@error('prisijungimo_vardas'){{ $message }} @enderror</span>
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-control" name="slaptazodis" placeholder="Slaptažodis">
                        <span class="text-danger">@error('slaptazodis'){{ $message }} @enderror</span>
                    </div>
                    <button type="submit" class="btn btn-block btn-primary">Prisijungti</button>
                    <br>
                </form>
            </div>
        </div>
    </div>
    <div class="container mx-auto" style="border-style: solid; border-width: 0px 3px 3px 3px; background-color: #B08348;">
        <h6 class="text-center">©kpikvs.lt visos teisės saugomos</h6>
    </div>
</body>

</html>