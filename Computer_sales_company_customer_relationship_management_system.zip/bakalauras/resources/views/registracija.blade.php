<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Registracija</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
<div class="container mx-auto" style="margin-top:50px; border-style: solid; border-width: 3px 3px 1px 3px; background-color: #B08348;">
        <h4 class="text-center">Registracijos puslapis</h4>
    </div>
    <div class="container" style="border-style: solid; border-width: 2px 3px 3px 3px; background-color: #DEB887;">
        <div class="row" style="margin-top:45px ; margin-bottom:45px ;">
            <div class="col-md-4 mx-auto">
                <div class="text-center" style="margin-bottom:30px;">
                    <h5>Registracija</h5>
                </div>
                <form action="{{ route('uzregistruoti') }}" method="post">

                    @if(Session::get('Pavyko'))
                    <div class='alert alert-success'>
                        {{ Session::get('Pavyko') }}
                    </div>
                    @endif

                    @if(Session::get('Klaida'))
                    <div class='alert alert-danger'>
                        {{ Session::get('Klaida') }}
                    </div>
                    @endif

                    @csrf
                    <div class="form-group">
                        <input type="text" class="form-control" name="el_pastas" placeholder="El. Paštas" value="{{ old('el_pastas') }}">
                        <span class="text-danger">@error('el_pastas'){{ $message }} @enderror</span>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" name="vardas" placeholder="Vardas" value="{{ old('vardas') }}">
                        <span class="text-danger">@error('vardas'){{ $message }} @enderror</span>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" name="pavarde" placeholder="Pavardė" value="{{ old('pavarde') }}">
                        <span class="text-danger">@error('pavarde'){{ $message }} @enderror</span>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" name="prisijungimo_vardas" placeholder="Prisijungimo vardas (ilgis: 4-20)" value="{{ old('prisijungimo_vardas') }}">
                        <span class="text-danger">@error('prisijungimo_vardas'){{ $message }} @enderror</span>
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-control" name="slaptazodis" placeholder="Slaptažodis (ilgis: 4-20)">
                        <span class="text-danger">@error('slaptazodis'){{ $message }} @enderror</span>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" name="miestas" placeholder="Miestas" value="{{ old('miestas') }}">
                        <span class="text-danger">@error('miestas'){{ $message }} @enderror</span>
                    </div>
                    <div class="form-group">
                        <input type="number" class="form-control" name="amzius" placeholder="Amžius" value="{{ old('amzius') }}">
                        <span class="text-danger">@error('amzius'){{ $message }} @enderror</span>
                    </div>
                    <div class="form-group">
                        <input type="tel" class="form-control" name="tel_nr" placeholder="Telefono numeris (370...)" value="{{ old('tel_nr') }}">
                        <span class="text-danger">@error('tel_nr'){{ $message }} @enderror</span>
                    </div>
                    <button type="submit" class="btn btn-block btn-primary">Registruotis</button>
                    <br>
                    <a class="btn btn-dark" style="margin-left:145px;" href="{{ route('pagrindinis') }}" role="button">Atgal</a>
                </form>
            </div>
        </div>
    </div>
    <div class="container mx-auto" style="border-style: solid; border-width: 0px 3px 3px 3px; background-color: #B08348;">
        <h6 class="text-center">©kpikvs.lt visos teisės saugomos</h6>
    </div>
</body>

</html>