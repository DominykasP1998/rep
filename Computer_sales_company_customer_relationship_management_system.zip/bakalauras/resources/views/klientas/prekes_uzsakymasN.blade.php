<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Prekės '{{ $preke->pavadinimas }}' užsakymas</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
    <div class="container mx-auto" style="margin-top:50px; border-style: solid; border-width: 3px 3px 1px 3px; background-color: #B08348;">
        <h4 class="text-center">Prekės '{{ $preke->pavadinimas }}' užsakymas</h4>
    </div>
    <div class="container" style="border-style: solid; border-width: 2px 3px 3px 3px; background-color: #DEB887;">
    <nav class="navbar navbar-light" style="background-color: #e3f2fd; margin-left:-15px; border-style: solid; border-width: 0px 0px 3px 0px;">
            <ul class="nav justify-content-left">
                <li class="nav-item active">
                    <a class="nav-link" href="/kliento_panele" style="border-style:solid;">Valdymo skydas <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/noru_sarasas" style="border-style:solid; margin-left:5px;">Norų sąrašas</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link disabled" href="" style="border-style:solid; margin-left:5px;">Prekės '{{ $preke->pavadinimas }}' užsakymas</a>
                </li>
            </ul>
        </nav>
        <div class="row" style="margin-top:45px; margin-bottom:45px ;">
            <div class="col-md-4 mx-auto">
                <div class="text-center" style="margin-bottom:30px;">
                    <h5>Prekės '{{ $preke->pavadinimas }}' užsakymas</h5>
                </div>
                <form action="<?php echo $preke->id ?>" method="post">

                    @if(Session::get('Klaida'))
                    <div class='alert alert-danger text-center' style="margin-left:auto; margin-right:auto;">
                        {{ Session::get('Klaida') }}
                    </div>
                    @endif

                    @csrf
                    <div class="form-group" style="width:70%; margin-left:auto; margin-right:auto;">
                        <input type="text" class="form-control" name="adresas" placeholder="Pristatymo adresas" value="{{ old('adresas') }}">
                        <span class="text-danger">@error('adresas'){{ $message }} @enderror</span>
                    </div>
                    <div class="form-group" style="width:70%; margin-left:auto; margin-right:auto;">
                        <input type="text" class="form-control" name="miestas" placeholder="Miestas" value="{{ old('miestas') }}">
                        <span class="text-danger">@error('miestas'){{ $message }} @enderror</span>
                    </div>
                    <div class="form-group" style="width:70%; margin-left:auto; margin-right:auto;">
                        <input type="number" class="form-control" name="kodas" placeholder="Pašto kodas" value="{{ old('kodas') }}">
                        <span class="text-danger">@error('kodas'){{ $message }} @enderror</span>
                    </div>
                    <select class="form-control" name="budas" style="margin-left:50px; width:70%; margin-bottom:30px;" value="{{ old('minutes') }}">
                            <option selected value="mb">Pasirinkite mokėjimo būdą</option>
                            <option value="Grynais atsiimant prekę">Grynais atsiimant prekę</option>
                            <option value="Bankiniu pavedimu">Bankiniu pavedimu</option>
                    </select>
                    <button type="submit" class="btn btn-block btn-primary" style="width:70%; margin-left:auto; margin-right:auto;">Užsakyti</button>
                    <br>
                </form>
            </div>
        </div>
    </div>
    <div class="container mx-auto" style="border-style: solid; border-width: 0px 3px 3px 3px; background-color: #B08348;">
        <h6 class="text-center">©kpikvs.lt visos teisės saugomos</h6>
    </div>
</body>

</html>