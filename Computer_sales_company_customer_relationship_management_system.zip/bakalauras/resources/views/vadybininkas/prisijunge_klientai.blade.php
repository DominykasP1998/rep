<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Prisijungę klientai</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
    <div class="container" style="margin-top:50px; border-style: solid; border-width: 3px 3px 1px 3px; background-color: #B08348;">
        <h4 class="text-center">Prisijungę klientai</h4>
    </div>
    <div class="container mx-auto" style="border-style: solid; background-color: #DEB887;">
    <nav class="navbar navbar-light" style="background-color: #e3f2fd; margin-left:-15px; border-style: solid; border-width: 0px 0px 3px 0px;">
                <ul class="nav justify-content-left">
                    <li class="nav-item active">
                        <a class="nav-link" href="/vadybininko_panele" style="border-style:solid;">Valdymo skydas <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link disabled" href="/prisijunge_klientai" style="border-style:solid; margin-left:5px;">Prisijungę klientai</a>
                    </li>
                </ul>
    </nav>
        <h6 class="text-center" style="margin-top:50px; margin-bottom:50px;">Šiuo metu prie sistemos prisijungę klientai</h6>

        @if(Session::get('Sėkmė'))
        <div class='alert alert-success text-center' style="width:95%; margin-left:auto; margin-right:auto;">
            {{ Session::get('Sėkmė') }}
        </div>
        @endif

        <table class="table table-light" style="margin-bottom:30px; width:95%; margin-left:auto; margin-right:auto;">
            <thead class="thead-dark">
                <tr>
                    <th scope="col">Prisijungimo vardas</th>
                    <th scope="col">El.Paštas</th>
                    <th scope="col">Vardas</th>
                    <th scope="col">Pavardė</th>
                    <th scope="col">Miestas</th>
                    <th scope="col">Amžius</th>
                    <th scope="col">Tel.Nr.</th>
                    <th scope="col">Rolė</th>
                    <th scope="col">Veiksmas</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($prisijunge as $p)
                <tr>
                    <td>{{ $p->prisijungimo_vardas }}</td>
                    <td>{{ $p->el_pastas }}</td>
                    <td>{{ $p->vardas }}</td>
                    <td>{{ $p->pavarde}}</td>
                    <td>{{ $p->miestas}}</td>
                    <td>{{ $p->amzius}}</td>
                    <td>{{ $p->tel_nr}}</td>
                    <td>{{ $p->role }}</td>
                    <td><a class="btn btn-info" href="pasiulyti/{{ $p->prisijungimo_vardas }}" role="button">Pasiūlyti prekę</a></td>
                </tr>
                @endforeach
            </tbody>
        </table>
        <div style="margin-left:493px;">
            {{ $prisijunge->links() }}
        </div>
        <a class="btn btn-dark" style="margin-bottom:30px; margin-left:525px;" href="{{ route('vadybininkop') }}" role="button">Atgal</a>
    </div>
    <div class="container mx-auto" style="border-style: solid; border-width: 0px 3px 3px 3px; background-color: #B08348;">
        <h6 class="text-center">©kpikvs.lt visos teisės saugomos</h6>
    </div>
</body>

</html>