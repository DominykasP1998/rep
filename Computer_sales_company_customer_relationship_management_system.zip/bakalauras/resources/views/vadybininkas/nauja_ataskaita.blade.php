<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pardavimų ataskaitos kūrimas</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
    <div class="container mx-auto" style="margin-top:50px; border-style: solid; border-width: 3px 3px 1px 3px; background-color: #B08348;">
        <h4 class="text-center">Pardavimų ataskaitos kūrimas</h4>
    </div>
    <div class="container" style="border-style: solid; border-width: 2px 3px 3px 3px; background-color: #DEB887;">
    <nav class="navbar navbar-light" style="background-color: #e3f2fd; margin-left:-15px; border-style: solid; border-width: 0px 0px 3px 0px;">
                <ul class="nav justify-content-left">
                    <li class="nav-item active">
                        <a class="nav-link" href="/vadybininko_panele" style="border-style:solid;">Valdymo skydas <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/pardavimu_ataskaitos" style="border-style:solid; margin-left:5px;">Pardavimo ataskaitos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link disabled" href="/nauja_pard_ataskaita" style="border-style:solid; margin-left:5px;">Nauja pardavimų ataskaita</a>
                    </li>
                </ul>
    </nav>
        <div class="row" style="margin-top:45px; margin-bottom:45px ;">
            <div class="col-md-4 mx-auto">
                <div class="text-center" style="margin-bottom:30px;">
                    <h5>Naujos ataskaitos kūrimas</h5>
                </div>
                <form action="{{ route('pateikti_pard') }}" method="post">

                    @if(Session::get('Klaida'))
                    <div class='alert alert-danger text-center' style="margin-left:auto; margin-right:auto;">
                        {{ Session::get('Klaida') }}
                    </div>
                    @endif

                    @csrf
                    <div class="form-group">
                        <input type="number" class="form-control" name="kiek_pasiule" placeholder="Kiek klientų pasiūlėte prekę" value="{{ old('kiek_pasiule') }}">
                        <span class="text-danger">@error('kiek_pasiule'){{ $message }} @enderror</span>
                    </div>
                    <div class="form-group">
                        <input type="number" class="form-control" name="kiek_uzsisake" placeholder="Kiek iš pasiūlytų užsisakė" value="{{ old('kiek_uzsisake') }}">
                        <span class="text-danger">@error('kiek_uzsisake'){{ $message }} @enderror</span>
                    </div>
                    <div class="form-group">
                        <input type="number" class="form-control" name="uz" min="0" value="0" step="0.01" pattern="^\d+(?:\.\d{1,2})?$" placeholder="Parduota prekių už" value="{{ old('uz') }}">
                        <span class="text-danger">@error('uz'){{ $message }} @enderror</span>
                    </div>
                    <button type="submit" class="btn btn-block btn-primary">Pateikti</button>
                    <br>
                </form>
            </div>
        </div>
    </div>
    <div class="container mx-auto" style="border-style: solid; border-width: 0px 3px 3px 3px; background-color: #B08348;">
        <h6 class="text-center">©kpikvs.lt visos teisės saugomos</h6>
    </div>
</body>

</html>