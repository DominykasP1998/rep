<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pokalbių ataskaitos</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
    <div class="container" style="margin-top:50px; border-style: solid; border-width: 3px 3px 1px 3px; background-color: #B08348;">
        <h4 class="text-center">Pokalbių ataskaitos</h4>
    </div>
    <div class="container mx-auto" style="border-style: solid; background-color: #DEB887;">
    <nav class="navbar navbar-light" style="background-color: #e3f2fd; margin-left:-15px; border-style: solid; border-width: 0px 0px 3px 0px;">
                <ul class="nav justify-content-left">
                    <li class="nav-item active">
                        <a class="nav-link" href="/konsultanto_panele" style="border-style:solid;">Valdymo skydas <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link disabled" href="/pokalbiu_ataskaitos" style="border-style:solid; margin-left:5px;">Pokalbių ataskaitos</a>
                    </li>
                </ul>
    </nav>
        <h6 class="text-center" style="margin-top:50px; margin-bottom:50px;">Visos Jūsų pateiktos ataskaitos</h6>

        @if(Session::get('Sekme'))
        <div class='alert alert-success col-md-4 text-center' style="margin-left:auto; margin-right:auto;">
            {{ Session::get('Sekme') }}
        </div>
        @endif

        @if(Session::get('Klaida'))
        <div class='alert alert-danger col-md-4 text-center' style="margin-left:auto; margin-right:auto;">
            {{ Session::get('Klaida') }}
        </div>
        @endif
        <div class="text-center">
        <?php $i = 0; ?>
        @foreach ($pateiktos as $p)
        <?php $i++; ?>
        <a class="text-dark" href="p_ataskaita/{{ $p->id }}">Pokalbių ataskaita 'PA{{ $i }}' {{ $p->pateikimo_data }}</a> <br>
        @endforeach
        </div>
        <div style="margin-left:493px; margin-top:50px;">
            {{ $pateiktos->links() }}
        </div>
            <a class="btn btn-success" style="margin-bottom:30px; margin-left:500px; margin-top:25px;" href="{{ route('nauja_p_ataskaita') }}" role="button">Kurti naują</a>
    </div>
    <div class="container mx-auto" style="border-style: solid; border-width: 0px 3px 3px 3px; background-color: #B08348;">
        <h6 class="text-center">©kpikvs.lt visos teisės saugomos</h6>
    </div>
</body>

</html>