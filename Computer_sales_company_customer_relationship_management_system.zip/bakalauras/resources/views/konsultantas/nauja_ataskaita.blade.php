<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pokalbių ataskaitos kūrimas</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
    <div class="container mx-auto" style="margin-top:50px; border-style: solid; border-width: 3px 3px 1px 3px; background-color: #B08348;">
        <h4 class="text-center">Pokalbių ataskaitos kūrimas</h4>
    </div>
    <div class="container" style="border-style: solid; border-width: 2px 3px 3px 3px; background-color: #DEB887;">
    <nav class="navbar navbar-light" style="background-color: #e3f2fd; margin-left:-15px; border-style: solid; border-width: 0px 0px 3px 0px;">
                <ul class="nav justify-content-left">
                    <li class="nav-item active">
                        <a class="nav-link" href="/konsultanto_panele" style="border-style:solid;">Valdymo skydas <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/pokalbiu_ataskaitos" style="border-style:solid; margin-left:5px;">Pokalbių ataskaitos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link disabled" href="" style="border-style:solid; margin-left:5px;">Naujos ataskaitos kūrimas</a>
                    </li>
                </ul>
    </nav>
        <div class="row" style="margin-top:45px; margin-bottom:45px ;">
            <div class="col-md-4 mx-auto">
                <div class="text-center" style="margin-bottom:30px;">
                    <h5>Naujos ataskaitos kūrimas</h5>
                </div>
                <form action="{{ route('pateikti') }}" method="post">
                    @csrf
                    <div class="form-group">
                        <input type="text" class="form-control" name="kv" placeholder="Kliento vardas" value="{{ old('kv') }}">
                        <span class="text-danger">@error('kv'){{ $message }} @enderror</span>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" name="kp" placeholder="Kliento pavardė" value="{{ old('kp') }}">
                        <span class="text-danger">@error('kp'){{ $message }} @enderror</span>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" name="kpv" placeholder="Kliento prisijungimo vardas" value="{{ old('kpv') }}">
                        <span class="text-danger">@error('kpv'){{ $message }} @enderror</span>
                    </div>
                    <div class="form-group">
                        <input type="number" class="form-control" name="amzius" placeholder="Amžius" value="{{ old('amzius') }}">
                        <span class="text-danger">@error('amzius'){{ $message }} @enderror</span>
                    </div>
                    <div class="form-group">
                        <input type="tel" class="form-control" name="tel_nr" placeholder="Telefono numeris (370...)" value="{{ old('tel_nr') }}">
                        <span class="text-danger">@error('tel_nr'){{ $message }} @enderror</span>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" name="miestas" placeholder="Miestas" value="{{ old('miestas') }}">
                        <span class="text-danger">@error('miestas'){{ $message }} @enderror</span>
                    </div>
                    <div class="form-group">
                        <input type="number" class="form-control" name="trukme" placeholder="Pokalbio trukmė (min.)" value="{{ old('trukme') }}">
                        <span class="text-danger">@error('trukme'){{ $message }} @enderror</span>
                    </div>
                    <div class="form-group">
                        <input type="tel" class="form-control" name="busena" placeholder="Spėjama kliento būsena" value="{{ old('busena') }}">
                        <span class="text-danger">@error('busena'){{ $message }} @enderror</span>
                    </div>
                    <button type="submit" class="btn btn-block btn-primary">Pateikti</button>
                    <br>
                </form>
            </div>
        </div>
    </div>
    <div class="container mx-auto" style="border-style: solid; border-width: 0px 3px 3px 3px; background-color: #B08348;">
        <h6 class="text-center">©kpikvs.lt visos teisės saugomos</h6>
    </div>
</body>

</html>