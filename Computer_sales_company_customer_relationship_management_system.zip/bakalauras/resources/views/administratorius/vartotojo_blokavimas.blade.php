<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Vartotojo '{{ $pv->prisijungimo_vardas }}' blokavimas</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
    <div class="container mx-auto" style="margin-top:50px; border-style: solid; border-width: 3px 3px 1px 3px; background-color: #B08348;">
        <h4 class="text-center">Vartotojo '{{ $pv->prisijungimo_vardas }}' blokavimas</h4>
    </div>
    <div class="container" style="border-style: solid; background-color: #DEB887;">
    @if (url()->previous() == "http://kpikvs.lt/atsiliepimai")
    <nav class="navbar navbar-light" style="background-color: #e3f2fd; margin-left:-15px; border-style: solid; border-width: 0px 0px 3px 0px;">
                <ul class="nav justify-content-left">
                    <li class="nav-item active">
                        <a class="nav-link" href="/admin_panele" style="border-style:solid;">Valdymo skydas <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/atsiliepimai" style="border-style:solid; margin-left:5px;">Atsiliepimai</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link disabled" href="" style="border-style:solid; margin-left:5px;">Vartotojo '{{ $pv->prisijungimo_vardas }}' blokavimas</a>
                    </li>
                </ul>
    </nav>
    @else
    <nav class="navbar navbar-light" style="background-color: #e3f2fd; margin-left:-15px; border-style: solid; border-width: 0px 0px 3px 0px;">
                <ul class="nav justify-content-left">
                    <li class="nav-item active">
                        <a class="nav-link" href="/admin_panele" style="border-style:solid;">Valdymo skydas <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/forumas" style="border-style:solid; margin-left:5px;">Forumas</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ url()->previous() }}" style="border-style:solid; margin-left:5px;">Temos žinutės</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link disabled" href="" style="border-style:solid; margin-left:5px;">Vartotojo '{{ $pv->prisijungimo_vardas }}' blokavimas</a>
                    </li>
                </ul>
    </nav>
    @endif
        <div class="row" style="margin-top:45px ; margin-bottom:45px ;">
            <div class="col-md-4 mx-auto">
                <div class="text-center" style="margin-bottom:30px;">
                    <h5>Vartotojo '{{ $pv->prisijungimo_vardas }}' blokavimas</h5>
                </div>
                <form class="form-group" action="<?php echo $pv->prisijungimo_vardas; ?>" method="post">
                    @if(Session::get('Klaida'))
                    <div class='alert alert-danger'>
                        {{ Session::get('Klaida') }}
                    </div>
                    @endif
                    @csrf
                    <select class="form-control" name="prie" style="margin-bottom:30px; width:70%; margin-left:auto; margin-right:auto;">
                        <option selected value="Priežastis">Priežastis</option>
                        <option value="Necenzūriniai žodžiai">Necenzūriniai žodžiai</option>
                        <option value="Grasinimai">Grasinimai</option>
                    </select>
                    <select class="form-control" name="truk" style="margin-bottom:30px; width:30%; margin-left:auto; margin-right:auto;">
                        <option selected value="Trukmė">Trukmė</option>
                        <option value="24">24 val.</option>
                        <option value="48">48 val.</option>
                        <option value="72">72 val.</option>
                    </select>
                    <button type="submit" class="btn btn-block btn-primary" style="width:70%; margin-left:55px;">Blokuoti</button>
                    <br>
                </form>
            </div>
        </div>
    </div>
    <div class="container mx-auto" style="border-style: solid; border-width: 0px 3px 3px 3px; background-color: #B08348;">
        <h6 class="text-center">©kpikvs.lt visos teisės saugomos</h6>
    </div>
</body>

</html>