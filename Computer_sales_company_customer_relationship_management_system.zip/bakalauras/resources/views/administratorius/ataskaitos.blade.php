<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ataskaitos</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
    <div class="container" style="margin-top:50px; border-style: solid; border-width: 3px 3px 1px 3px; background-color: #B08348;">
        <h4 class="text-center">Ataskaitos</h4>
    </div>
    <div class="container mx-auto" style="border-style: solid; background-color: #DEB887;">
    <nav class="navbar navbar-light" style="background-color: #e3f2fd; margin-left:-15px; border-style: solid; border-width: 0px 0px 3px 0px;">
                <ul class="nav justify-content-left">
                    <li class="nav-item active">
                        <a class="nav-link" href="/admin_panele" style="border-style:solid;">Valdymo skydas <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/ags" style="border-style:solid; margin-left:5px;">Ataskaitos, grafikai, statistika</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link disabled" href="" style="border-style:solid; margin-left:5px;">Ataskaitos</a>
                    </li>
                </ul>
    </nav>
        <h6 class="text-center" style="margin-top:50px; margin-bottom:50px;">Visos pateiktos ataskaitos</h6>
        <div class="text-center">
        <?php $i = 0; ?>
        @foreach ($pokalbiu as $p)
        <?php $i++; ?>
        <a class="text-dark" href="pokalbiu_ataskaita/{{ $p->id }}">Pokalbių ataskaita 'PA{{ $i }}' {{ $p->pateikimo_data }}</a> <br>
        @endforeach
        </div>
        <div class="text-center">
        <?php $j = 0; ?>
        @foreach ($pardavimu as $pa)
        <?php $j++; ?>
        <a class="text-dark" href="pardavimu_ataskaita/{{ $pa->Id }}">Pardavimų ataskaita 'PA{{ $j }}' {{ $pa->pateikimo_data }}</a> <br>
        @endforeach
        </div>
        <div style="margin-left:493px; margin-top:50px;">
            {{ $pardavimu->links() }}
        </div>
    </div>
    <div class="container mx-auto" style="border-style: solid; border-width: 0px 3px 3px 3px; background-color: #B08348;">
        <h6 class="text-center">©kpikvs.lt visos teisės saugomos</h6>
    </div>
</body>

</html>