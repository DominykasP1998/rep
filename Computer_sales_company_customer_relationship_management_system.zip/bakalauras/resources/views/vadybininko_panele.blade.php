<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Vadybininko panelė</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
    <div class="container mx-auto" style="margin-top:50px; border-style: solid; border-width: 3px 3px 1px 3px; background-color: #B08348;">
        <h4 class="text-center">Vadybininko valdymo skydas</h4>
    </div>
    <div class="container" style="border-style: solid; background-color: #DEB887;">
    <nav class="navbar navbar-light" style="background-color: #e3f2fd; margin-left:-15px; border-style: solid; border-width: 0px 0px 3px 0px;">
                <ul class="nav justify-content-left">
                    <li class="nav-item active">
                        <a class="nav-link disabled" href="/vadybininko_panele" style="border-style:solid;">Valdymo skydas <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/prekes" style="border-style:solid; margin-left:5px;">Prekių sąrašas</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/prisijunge_klientai" style="border-style:solid; margin-left:5px;">Prisijungę klientai</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/pardavimu_ataskaitos" style="border-style:solid; margin-left:5px;">Pardavimo ataskaitos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('pagrindinis') }}" style="color: red; border-style:solid; margin-left:5px;">Atsijungti</a>
                    </li>
                </ul>
    </nav>
        <h5 class="text-center" style="margin-top:50px; margin-bottom:30px;">Sveiki, {{ $Info['prisijungimo_vardas'] }}!</h5>
    </div>
    <div class="container mx-auto" style="border-style: solid; border-width: 0px 3px 3px 3px; background-color: #B08348;">
        <h6 class="text-center">©kpikvs.lt visos teisės saugomos</h6>
    </div>
</body>

</html>