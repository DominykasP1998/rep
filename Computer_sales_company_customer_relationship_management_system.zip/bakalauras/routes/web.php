<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MainController;
use App\Http\Controllers\adminC;
use App\Http\Controllers\vadC;
use App\Http\Controllers\konC;
use App\Http\Controllers\klientoC;
use App\Models\prijungimas;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//RegPrisAts
Route::get('/', [MainController::class, 'pagrindinis'])->name('pagrindinis');
Route::get('/registracija', [MainController::class, 'registruotis'])->name('registracija');
Route::post('/uzregistruoti', [MainController::class, 'uzregistruoti'])->name('uzregistruoti');
Route::post('/prijungimas', [MainController::class, 'prijungimas'])->name('prijungimas');

//Keliai į paneles
Route::get('/kliento_panele', [MainController::class, 'klientop'])->name('klientop');
Route::get('/admin_panele', [MainController::class, 'adminop'])->name('adminop');
Route::get('/vadybininko_panele', [MainController::class, 'vadybininkop'])->name('vadybininkop');
Route::get('/konsultanto_panele', [MainController::class, 'konsultantop'])->name('konsultantop');

//Administratoriaus funkcijų keliai
Route::get('/registruoti_vartotojai', [adminC::class, 'gautiRegistruotus'])->name('registruoti');
Route::get('role/{pv}', [adminC::class, 'gautiPV']);
Route::post('role/{pv}', [adminC::class, 'suteiktiRolę'])->name('role');
Route::get('/ags', [adminC::class, 'ags'])->name('ags');
Route::get('/forumas', [adminC::class, 'forumas'])->name('forumas');
Route::get('/atsiliepimai', [adminC::class, 'atsiliepimai'])->name('atsiliepimai');
Route::get('/naikinti_tema/{id}', [adminC::class, 'naikinti_tema']);
Route::get('/temos/{id}', [adminC::class, 'zinutes'])->name('zinutes');
Route::get('/naikinti_zinute/{id}', [adminC::class, 'naikinti_zinute']);
Route::get('/naikinti_atsiliepima/{id}', [adminC::class, 'naikinti_atsiliepima']);
Route::get('/blokuoti_vartotoja/{pv}', [adminC::class, 'blokuoti_vartotoja']);
Route::post('/blokuoti_vartotoja/{pv}', [adminC::class, 'blokuoti_vartotoja_commit'])->name('blokuoti');
Route::post('/pasirinkimas', [adminC::class, 'pasirinkimas'])->name('pasirinkimas');
Route::get('/ataskaitos', [adminC::class, 'ataskaitos'])->name('ataskaitos');
Route::get('/pokalbiu_ataskaita/{id}', [adminC::class, 'gautiPokalbiuID']);
Route::get('/pardavimu_ataskaita/{id}', [adminC::class, 'gautiPardavimuID']);

//Vadybininko funckijų keliai
Route::get('/prekes', [vadC::class, 'prekes'])->name('prekes');
Route::get('/prisijunge_klientai', [vadC::class, 'prisijunge'])->name('prisijunge');
Route::get('/pardavimu_ataskaitos', [vadC::class, 'pardavimu'])->name('pardavimu');
Route::get('/nauja_pard_ataskaita', [vadC::class, 'nauja_pard'])->name('nauja_pard');
Route::post('/pateikti_pard_ataskaita', [vadC::class, 'pateikti_pard'])->name('pateikti_pard');
Route::get('/pard_ataskaita/{id}', [vadC::class, 'gautiPardID']);
Route::get('nustatyti_n/{id}', [vadC::class, 'gautiPrekID']);
Route::post('nustatyti_n/{id}', [vadC::class, 'nustatytiNuolaidą'])->name('nustatyti');
Route::get('pasiulyti/{id}', [vadC::class, 'pasiūlytiPrekę']);
Route::get('/siulyti/{id}', [vadC::class, 'siūlyti']);

//Konsultanto funkcijų keliai
Route::get('/pokalbiu_ataskaitos', [konC::class, 'pokalbiu'])->name('pokalbiu');
Route::get('/nauja_p_ataskaita', [konC::class, 'nauja_p_ataskaita'])->name('nauja_p_ataskaita');
Route::post('/pateikti_p_ataskaita', [konC::class, 'pateikti'])->name('pateikti');
Route::get('/p_ataskaita/{id}', [konC::class, 'gautiPID']);

//Kliento funkcijų keliai
Route::get('/prekiu_sarasas', [klientoC::class, 'prekiu'])->name('prekiu');
Route::get('/noru_sarasas', [klientoC::class, 'norai'])->name('norai');
Route::get('/registracija_pokalbiui', [klientoC::class, 'pokalbiui'])->name('pokalbiui');
Route::get('/patarimai', [klientoC::class, 'patarimai'])->name('patarimai');
Route::get('/atsiliepimai_k', [klientoC::class, 'atsiliepimai_k'])->name('atsiliepimai_k');
Route::get('/serveriai', [klientoC::class, 'serveriai'])->name('serveriai');
Route::get('/forumas_k', [klientoC::class, 'forumas_k'])->name('forumas_k');
Route::post('/uzregistruoti_pokalbiui', [klientoC::class, 'uzregistruoti_p'])->name('uzregistruoti_p');
Route::get('/temos_k/{id}', [klientoC::class, 'zinutes_k'])->name('zinutes_k');
Route::post('/rasyti_zinute/{id}', [klientoC::class, 'rasyti_zinute'])->name('rasyti_zinute');
Route::post('/rasyti_atsiliepima', [klientoC::class, 'rasyti_atsiliepima'])->name('rasyti_atsiliepima');
Route::get('/gautiKonsultantus', [klientoC::class, 'gautiKonsultantus'])->name('gautiKonsultantus');
Route::get('/gautiVadybininkus', [klientoC::class, 'gautiVadybininkus'])->name('gautiVadybininkus');
Route::get('/gautiPrekes', [klientoC::class, 'gautiPrekes'])->name('gautiPrekes');
Route::get('naikinti_nora/{id}', [klientoC::class, 'naikintiNorą']);
Route::get('/f_uzsakyma_pn/{id}', [klientoC::class, 'formuotiUžsakymąN']);
Route::post('/f_uzsakyma_pn/{id}', [klientoC::class, 'formuotiN']);
Route::get('/f_uzsakyma_ps/{id}', [klientoC::class, 'formuotiUžsakymąS']);
Route::post('/f_uzsakyma_ps/{id}', [klientoC::class, 'formuotiS']);
Route::get('/gautiPatarimus', [klientoC::class, 'gautiPatarimus'])->name('gautiPatarimus');
Route::post('/perziureti_patarimus', [klientoC::class, 'peržiūrėtiPatarimus']);
Route::get('/siulomi_serveriai', [klientoC::class, 'siūlomiServeriai'])->name('siūlomiServeriai');
Route::get('/serverio_uzsakymas', [klientoC::class, 'užsakytiS']);
Route::post('/užsakyti_ser', [klientoC::class, 'užsakytiSer']);
Route::get('i_noru_sarasa/{id}', [klientoC::class, 'pridėtiNorą']);